(() => {
  'use strict';

  const STATUS = {
    WEEKLY: '週週聚會',
    REGULAR: '常聚會',
    OCCASIONAL: '偶聚會',
    SPORADIC: '零星聚會',
    INACTIVE: '近期未聚會'
  };

  const STATUS_ORDER = [
    STATUS.WEEKLY,
    STATUS.REGULAR,
    STATUS.OCCASIONAL,
    STATUS.SPORADIC,
    STATUS.INACTIVE
  ];

  const STATUS_CLASS = {
    [STATUS.WEEKLY]: 'weekly',
    [STATUS.REGULAR]: 'regular',
    [STATUS.OCCASIONAL]: 'occasional',
    [STATUS.SPORADIC]: 'sporadic',
    [STATUS.INACTIVE]: 'inactive'
  };

  const MS_WEEK =
    7 * 24 * 60 * 60 * 1000;


  const state = {
    fileName: '',
    rows: [],
    dateColumns: [],
    people: [],
    windowWeeks: 12,
    indexes: {},
    recentCols: [],

    baptismFileName: '',
    baptismByName: new Map(),

    selectedGroups: new Set(),
    selectedStatuses: new Set(),

    /* 分析篩選：小區可複選；空集合代表全部小區 */
    selectedAnalysisSmallDistricts: new Set(),

    /*
     * 羣組成長趨勢：按鈕可複選。
     * 第一次載入時預設顯示所有可用羣組。
     */
    selectedTrendGroups: new Set(),
    trendGroupsInitialized: false,
    groupTrendMode: 'groups',

    /* 季度比較：空白時由實際資料自動帶入「前一季 → 最新季」 */
    quarterFromKey: '',
    quarterToKey: '',

    /*
     * 人員明細區域複選篩選
     * 只影響人員明細，不影響四張分析圖。
     */
    selectedPeopleDistricts: new Set(),
    selectedPeopleSmallDistricts: new Set(),

    /*
     * 圖表點擊連動
     */
    chartType: '',
    chartGroup: '',
    chartDistrict: ''
  };


  const $ =
    id =>
      document.getElementById(id);


  const els = {
    fileInput: $('fileInput'),
    fileName: $('fileName'),
    baptismFileInput: $('baptismFileInput'),
    baptismFileName: $('baptismFileName'),
    error: $('errorMessage'),
    dashboard: $('dashboard'),
    clearBtn: $('clearBtn'),

    infoFile: $('infoFile'),
    infoPeriod: $('infoPeriod'),
    infoWeeks: $('infoWeeks'),
    infoPeople: $('infoPeople'),

    ruleText: $('ruleText'),

    summaryCards: $('summaryCards'),

    trendDistrictFilter:
      $('trendDistrictFilter'),

    trendSmallDistrictFilter:
      $('trendSmallDistrictFilter'),

    trendDistrictButtons:
      $('trendDistrictButtons'),

    trendSmallDistrictButtons:
      $('trendSmallDistrictButtons'),

    trendSmallDistrictGroup:
      $('trendSmallDistrictGroup'),

    trendScopeLabel:
      $('trendScopeLabel'),

    trendLatestCount:
      $('trendLatestCount'),

    trendAverageCount:
      $('trendAverageCount'),

    trendChangeText:
      $('trendChangeText'),

    quarterFromSelect:
      $('quarterFromSelect'),

    quarterToSelect:
      $('quarterToSelect'),

    trendFromQuarterLabel:
      $('trendFromQuarterLabel'),

    trendToQuarterLabel:
      $('trendToQuarterLabel'),

    currentAgeQuarterLabel:
      $('currentAgeQuarterLabel'),

    quarterComparePeriodLabel:
      $('quarterComparePeriodLabel'),

    quarterCompareFromLegend:
      $('quarterCompareFromLegend'),

    quarterCompareToLegend:
      $('quarterCompareToLegend'),

    trendChart:
      $('trendChart'),

    groupTrendScopeLabel:
      $('groupTrendScopeLabel'),

    groupTrendButtons:
      $('groupTrendButtons'),

    groupTrendSelectedText:
      $('groupTrendSelectedText'),

    groupTrendDistrictLegend:
      $('groupTrendDistrictLegend'),

    groupTrendChart:
      $('groupTrendChart'),

    currentAgePyramid:
      $('currentAgePyramid'),

    currentAgeStructureMeta:
      $('currentAgeStructureMeta'),

    quarterAgePyramid:
      $('quarterAgePyramid'),

    ageStructureSignal:
      $('ageStructureSignal'),

    overallBar: $('overallBar'),
    overallLegend: $('overallLegend'),

    districtBody:
      document.querySelector(
        '#districtTable tbody'
      ),

    searchInput: $('searchInput'),
    analysisDistrictButtons: $('analysisDistrictButtons'),
    analysisSmallDistrictButtons: $('analysisSmallDistrictButtons'),
    analysisSmallDistrictRow: $('analysisSmallDistrictRow'),
    analysisGroupButtons: $('analysisGroupButtons'),
    analysisStatusButtons: $('analysisStatusButtons'),
    analysisBelieverButtons: $('analysisBelieverButtons'),
    analysisBelieverRow: $('analysisBelieverRow'),
    districtFilter: $('districtFilter'),
    smallDistrictFilter:
      $('smallDistrictFilter'),

    totalAttendanceFilter:
      $('totalAttendanceFilter'),

    absenceWeeksFilter:
      $('absenceWeeksFilter'),

    populationOriginalCount:
      $('populationOriginalCount'),

    populationActiveCount:
      $('populationActiveCount'),

    populationExcludedCount:
      $('populationExcludedCount'),

    newBelieverFilter:
      $('newBelieverFilter'),

    groupMultiSelect:
      $('groupMultiSelect'),

    groupFilterSummary:
      $('groupFilterSummary'),

    groupFilterOptions:
      $('groupFilterOptions'),

    clearGroupFilter:
      $('clearGroupFilter'),

    closeGroupFilter:
      $('closeGroupFilter'),

    statusMultiSelect:
      $('statusMultiSelect'),

    statusFilterSummary:
      $('statusFilterSummary'),

    statusFilterOptions:
      $('statusFilterOptions'),

    clearStatusFilter:
      $('clearStatusFilter'),

    closeStatusFilter:
      $('closeStatusFilter'),

    resultCount:
      $('resultCount'),

    peopleBody:
      document.querySelector(
        '#peopleTable tbody'
      ),

    peopleDistrictMultiSelect:
      $('peopleDistrictMultiSelect'),

    peopleDistrictSummary:
      $('peopleDistrictSummary'),

    peopleDistrictOptions:
      $('peopleDistrictOptions'),

    clearPeopleDistrictFilter:
      $('clearPeopleDistrictFilter'),

    closePeopleDistrictFilter:
      $('closePeopleDistrictFilter'),

    peopleSmallDistrictMultiSelect:
      $('peopleSmallDistrictMultiSelect'),

    peopleSmallDistrictSummary:
      $('peopleSmallDistrictSummary'),

    peopleSmallDistrictOptions:
      $('peopleSmallDistrictOptions'),

    clearPeopleSmallDistrictFilter:
      $('clearPeopleSmallDistrictFilter'),

    closePeopleSmallDistrictFilter:
      $('closePeopleSmallDistrictFilter'),

    clearPeopleAreaFilter:
      $('clearPeopleAreaFilter'),

    chartFilterIndicator:
      $('chartFilterIndicator'),

    chartFilterText:
      $('chartFilterText'),

    clearChartFilter:
      $('clearChartFilter'),

    peoplePanel:
      $('peoplePanel')
  };


  function excelDateToDate(value) {

    if (
      value instanceof Date &&
      !Number.isNaN(
        value.getTime()
      )
    ) {
      return startOfDay(value);
    }


    if (
      typeof value === 'number'
    ) {

      const parts =
        XLSX.SSF.parse_date_code(
          value
        );

      if (!parts) {
        return null;
      }

      return new Date(
        parts.y,
        parts.m - 1,
        parts.d
      );
    }


    if (
      typeof value === 'string'
    ) {

      const s =
        value.trim();

      if (!s) {
        return null;
      }


      let m =
        s.match(
          /^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/
        );

      if (m) {
        return new Date(
          Number(m[1]),
          Number(m[2]) - 1,
          Number(m[3])
        );
      }


      m =
        s.match(
          /^(\d{4})[-\/.](\d{1,2})$/
        );

      if (m) {
        return new Date(
          Number(m[1]),
          Number(m[2]) - 1,
          1
        );
      }
    }


    return null;
  }


  function startOfDay(d) {

    return new Date(
      d.getFullYear(),
      d.getMonth(),
      d.getDate()
    );
  }


  /*
   * 新版點名系統的每週日期欄位以「週一」代表該週，
   * 但本系統分析的是主日聚會，因此遇到週一時自動 +6 天，
   * 換算成同一週的主日。
   *
   * 舊版報表本來就是週日日期，因此保持不變。
   */
  function normalizeAttendanceDateToSunday(d) {

    if (!d) {
      return null;
    }

    const normalized =
      startOfDay(d);

    // JavaScript：0 = 週日，1 = 週一
    if (normalized.getDay() === 1) {
      normalized.setDate(
        normalized.getDate() + 6
      );
    }

    return normalized;
  }


  function baptismValueToDate(value) {

    if (
      typeof value === 'string'
    ) {

      const s =
        value.trim();


      const m =
        s.match(
          /^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/
        );


      if (m) {

        const year = Number(m[1]);
        const month = Number(m[2]);
        const day = Number(m[3]);


        if (
          month < 1 ||
          month > 12 ||
          day < 1 ||
          day > 31
        ) {
          return null;
        }


        const d =
          new Date(
            year,
            month - 1,
            day
          );


        if (
          d.getFullYear() !== year ||
          d.getMonth() !== month - 1 ||
          d.getDate() !== day
        ) {
          return null;
        }


        return d;
      }
    }


    return excelDateToDate(
      value
    );
  }


  function isAttendance(value) {

    if (
      typeof value === 'number'
    ) {
      return value > 0;
    }


    if (
      typeof value === 'boolean'
    ) {
      return value;
    }


    if (
      typeof value === 'string'
    ) {

      const s =
        value
          .trim()
          .toLowerCase();

      return [
        '1',
        'v',
        '✓',
        '✔',
        'true',
        '有',
        '出席'
      ].includes(s);
    }


    return false;
  }


  function fmtDate(d) {

    return d
      ? `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`
      : '—';
  }


  function analyzeWorkbook(
    arrayBuffer,
    fileName
  ) {

    const workbook =
      XLSX.read(
        arrayBuffer,
        {
          type: 'array',
          cellDates: false,
          raw: true
        }
      );


    if (
      !workbook.SheetNames.length
    ) {
      throw new Error(
        '找不到工作表。'
      );
    }


    /*
     * 新版點名系統固定讀取「出席」工作表；
     * 舊版 export.xlsx 沒有此工作表時，維持讀第一張工作表。
     */
    const attendanceSheetName =
      workbook.SheetNames.includes('出席')
        ? '出席'
        : workbook.SheetNames[0];


    const sheet =
      workbook.Sheets[
        attendanceSheetName
      ];


    const rows =
      XLSX.utils.sheet_to_json(
        sheet,
        {
          header: 1,
          raw: true,
          defval: ''
        }
      );


    if (
      rows.length < 2
    ) {
      throw new Error(
        '出席工作表沒有足夠資料。'
      );
    }


    const header =
      rows[0].map(
        v =>
          String(
            v ?? ''
          ).trim()
      );


    const findHeaderIndex =
      names =>
        names
          .map(
            name =>
              header.indexOf(name)
          )
          .find(
            i => i >= 0
          ) ?? -1;


    const indexes = {
      district:
        findHeaderIndex(['大區']),
      smallDistrict:
        findHeaderIndex(['小區']),
      name:
        findHeaderIndex(['姓名']),
      group:
        findHeaderIndex(['羣組', '群組'])
    };


    const missing = [];

    if (indexes.district < 0) {
      missing.push('大區');
    }

    if (indexes.smallDistrict < 0) {
      missing.push('小區');
    }

    if (indexes.name < 0) {
      missing.push('姓名');
    }

    if (indexes.group < 0) {
      missing.push('羣組／群組');
    }


    if (
      missing.length
    ) {
      throw new Error(
        `缺少必要欄位：${missing.join('、')}`
      );
    }


    const baptismIndex =
      findHeaderIndex([
        '受浸日期',
        '受浸日',
        '受浸'
      ]);


    const today =
      new Date();


    today.setHours(
      23,
      59,
      59,
      999
    );


    const dateColumns = [];


    rows[0].forEach(
      (value, col) => {

        const rawDate =
          excelDateToDate(
            value
          );

        const d =
          normalizeAttendanceDateToSunday(
            rawDate
          );

        if (
          d &&
          d <= today
        ) {
          dateColumns.push({
            col,
            date: d
          });
        }
      }
    );


    dateColumns.sort(
      (a, b) =>
        a.date - b.date
    );


    if (
      !dateColumns.length
    ) {
      throw new Error(
        '找不到可辨識的聚會日期欄位。'
      );
    }


    state.fileName =
      fileName;

    state.rows =
      rows;

    state.dateColumns =
      dateColumns;


    state.indexes = {
      ...indexes,
      baptism:
        baptismIndex
    };


    /*
     * 匯入新點名報表時，
     * 清除上一份圖表點擊與人員明細區域篩選狀態。
     * 已匯入的受浸報表保留，可直接重新配對。
     */
    state.selectedPeopleDistricts =
      new Set();

    state.selectedPeopleSmallDistricts =
      new Set();

    state.selectedAnalysisSmallDistricts =
      new Set();

    state.chartType = '';
    state.chartGroup = '';
    state.chartDistrict = '';

    state.selectedTrendGroups =
      new Set();

    state.trendGroupsInitialized =
      false;

    state.quarterFromKey = '';
    state.quarterToKey = '';

    updateChartFilterUI();


    recalculate();


    if (
      baptismIndex < 0 &&
      !state.baptismByName.size
    ) {

      els.error.textContent =
        '提醒：點名報表沒有受浸日期，請再匯入受浸報表以顯示受浸日並判斷初信。';
    }
  }


  function analyzeBaptismWorkbook(
    arrayBuffer,
    fileName
  ) {

    const workbook =
      XLSX.read(
        arrayBuffer,
        {
          type: 'array',
          cellDates: false,
          raw: true
        }
      );


    const baptismSheetName =
      workbook.SheetNames.find(
        name =>
          String(name).trim() ===
          '受浸名單'
      );


    if (!baptismSheetName) {
      throw new Error(
        '受浸報表找不到第 5 個工作表「受浸名單」。'
      );
    }


    const rows =
      XLSX.utils.sheet_to_json(
        workbook.Sheets[
          baptismSheetName
        ],
        {
          header: 1,
          raw: true,
          defval: ''
        }
      );


    if (
      rows.length < 2
    ) {
      throw new Error(
        '「受浸名單」工作表沒有足夠資料。'
      );
    }


    const header =
      rows[0].map(
        v =>
          String(
            v ?? ''
          ).trim()
      );


    const nameIndex =
      header.indexOf('姓名');


    const baptismIndex =
      ['受浸日', '受浸日期', '受浸']
        .map(
          name =>
            header.indexOf(name)
        )
        .find(
          i => i >= 0
        ) ?? -1;


    if (
      nameIndex < 0 ||
      baptismIndex < 0
    ) {
      throw new Error(
        '「受浸名單」缺少「姓名」或「受浸日」欄位。'
      );
    }


    const baptismByName =
      new Map();


    rows
      .slice(1)
      .forEach(
        row => {

          const name =
            String(
              row[nameIndex] ?? ''
            ).trim();


          const baptismDate =
            baptismValueToDate(
              row[baptismIndex]
            );


          if (
            !name ||
            !baptismDate
          ) {
            return;
          }


          /*
           * 同姓名若在受浸名單出現多筆，採較新的受浸日。
           * 一般情況不會影響單一姓名資料。
           */
          const existing =
            baptismByName.get(name);


          if (
            !existing ||
            baptismDate > existing
          ) {
            baptismByName.set(
              name,
              baptismDate
            );
          }
        }
      );


    state.baptismFileName =
      fileName;

    state.baptismByName =
      baptismByName;


    els.baptismFileName.textContent =
      `${fileName}｜${baptismByName.size} 人有受浸日期`;


    if (
      state.rows.length
    ) {
      recalculate();
    }
  }


  function classify({
    attended,
    totalWeeks,
    weekly12Attendance,
    weekly12Weeks,
    weeksSinceLastAttendance
  }) {

    if (
      !totalWeeks ||
      weeksSinceLastAttendance === null ||
      weeksSinceLastAttendance > 8
    ) {
      return STATUS.INACTIVE;
    }


    if (
      weekly12Weeks >= 12 &&
      weekly12Attendance ===
        weekly12Weeks
    ) {
      return STATUS.WEEKLY;
    }


    const regularNeeded =
      Math.ceil(
        totalWeeks / 3
      );


    if (
      attended >=
        regularNeeded &&
      weeksSinceLastAttendance <= 3
    ) {
      return STATUS.REGULAR;
    }


    const occasionalNeeded =
      Math.ceil(
        totalWeeks / 4
      );


    if (
      attended >=
        occasionalNeeded &&
      weeksSinceLastAttendance <= 4
    ) {
      return STATUS.OCCASIONAL;
    }


    return STATUS.SPORADIC;
  }


  function recalculate() {

    if (
      !state.rows.length
    ) {
      return;
    }


    // 聚會情況固定以最近 12 週判定，不再提供切換。
    state.windowWeeks = 12;


    const recentCols =
      state.dateColumns.slice(
        -state.windowWeeks
      );


    state.recentCols =
      recentCols;


    const referenceDate =
      recentCols.length
        ? recentCols[
            recentCols.length - 1
          ].date
        : null;


    const { indexes } =
      state;


    const weekly12Cols =
      state.dateColumns.slice(-12);


    state.people =
      state.rows
        .slice(1)
        .map(
          (row, i) => {

            const name =
              String(
                row[
                  indexes.name
                ] ?? ''
              ).trim();


            if (!name) {
              return null;
            }


            const recentAttendance =
              recentCols.reduce(
                (sum, x) =>
                  sum +
                  (
                    isAttendance(
                      row[x.col]
                    )
                      ? 1
                      : 0
                  ),
                0
              );


            const weekly12Attendance =
              weekly12Cols.reduce(
                (sum, x) =>
                  sum +
                  (
                    isAttendance(
                      row[x.col]
                    )
                      ? 1
                      : 0
                  ),
                0
              );


            const attendedDates =
              state.dateColumns
                .filter(
                  x =>
                    isAttendance(
                      row[x.col]
                    )
                )
                .map(
                  x => x.date
                );


            const lastAttendanceDate =
              attendedDates.length
                ? attendedDates[
                    attendedDates.length - 1
                  ]
                : null;


            const weeksSinceLastAttendance =
              lastAttendanceDate &&
              referenceDate
                ? Math.floor(
                    (
                      referenceDate -
                      lastAttendanceDate
                    ) /
                    MS_WEEK
                  )
                : null;


            const totalAttendance =
              attendedDates.length;


            const baptismDate =
              indexes.baptism >= 0
                ? excelDateToDate(
                    row[
                      indexes.baptism
                    ]
                  )
                : (
                    state.baptismByName.get(
                      name
                    ) || null
                  );


            const weeksSinceBaptism =
              baptismDate &&
              referenceDate
                ? Math.floor(
                    (
                      referenceDate -
                      baptismDate
                    ) /
                    MS_WEEK
                  )
                : null;


            let newBelieverStatus =
              'unknown';


            if (
              weeksSinceBaptism !== null
            ) {

              newBelieverStatus =
                (
                  weeksSinceBaptism >= 0 &&
                  weeksSinceBaptism <= 104
                )
                  ? 'yes'
                  : 'no';
            }


            return {

              rowNumber:
                i + 2,

              district:
                String(
                  row[
                    indexes.district
                  ] ?? ''
                ).trim(),

              smallDistrict:
                String(
                  row[
                    indexes.smallDistrict
                  ] ?? ''
                ).trim(),

              name,

              group:
                String(
                  row[
                    indexes.group
                  ] ?? ''
                ).trim(),

              baptismDate,

              newBelieverStatus,

              isNewBeliever:
                newBelieverStatus ===
                'yes',

              recentAttendance,

              recentWeeks:
                recentCols.length,

              recentRate:
                recentCols.length
                  ? recentAttendance /
                    recentCols.length
                  : 0,

              totalAttendance,

              lastAttendanceDate,

              weeksSinceLastAttendance,

              weekly12Attendance,

              weekly12Weeks:
                weekly12Cols.length,

              status:
                classify({
                  attended:
                    recentAttendance,

                  totalWeeks:
                    recentCols.length,

                  weekly12Attendance,

                  weekly12Weeks:
                    weekly12Cols.length,

                  weeksSinceLastAttendance
                })
            };
          }
        )
        .filter(Boolean);


    renderAll();
  }


  function countStatuses(
    people
  ) {

    const counts =
      Object.fromEntries(
        STATUS_ORDER.map(
          s => [s, 0]
        )
      );


    people.forEach(
      p => {
        counts[p.status]++;
      }
    );


    return counts;
  }


  function renderAll() {

    renderInfo();

    renderRuleText();

    renderPopulationScope();

    renderSummary();

    buildQuarterCompareControls();

    buildTrendFilters();

    renderTrend();

    buildGroupTrendButtons();

    renderGroupTrend();

    renderOverall();

    renderDistricts();

    buildFilters();

    renderPeople();

    updateChartFilterUI();


    els.dashboard.classList.remove(
      'hidden'
    );


    els.clearBtn.disabled =
      false;
  }


  function renderInfo() {

    const allDates =
      state.dateColumns;

    const recent =
      state.recentCols;


    const latestDate =
      allDates[
        allDates.length - 1
      ].date;


    els.infoFile.textContent =
      state.fileName;


    els.infoPeriod.textContent =
      `${fmtDate(
        allDates[0].date
      )} – ${fmtDate(
        latestDate
      )}`;


    els.infoWeeks.textContent =
      `${allDates.length} 週｜目前分析：截至 ${fmtDate(
        latestDate
      )} 最近 ${recent.length} 週`;


    const population =
      getPopulationBase();

    els.infoPeople.textContent =
      population.exclusionActive
        ? `${population.people.length} 人（原 ${population.originalCount} 人）`
        : `${population.people.length} 人`;
  }


  function renderRuleText() {

    const actual =
      state.recentCols.length;


    const latestDate =
      state.dateColumns.length
        ? state.dateColumns[
            state.dateColumns.length - 1
          ].date
        : null;


    const earliestRecent =
      actual
        ? state.recentCols[0].date
        : null;


    const periodText =
      actual <
      state.windowWeeks
        ? `檔案目前只有 ${actual} 個有效週次`
        : `${fmtDate(
            earliestRecent
          )} – ${fmtDate(
            latestDate
          )}`;


    els.ruleText.textContent =
      `以匯入資料中最新主日 ${fmtDate(
        latestDate
      )} 為「目前」，累計最近 ${state.windowWeeks} 週（${periodText}）。初信＝受浸日期在目前截止日前 104 週內。`;
  }


  function renderSummary() {

    const people =
      getPopulationBase().people;

    const counts =
      countStatuses(
        people
      );


    const total =
      people.length || 1;


    const newBelievers =
      people.filter(
        p =>
          p.newBelieverStatus ===
          'yes'
      ).length;


    const cards = [

      [
        '總人數',
        people.length,
        '統計名單'
      ],

      [
        '初信',
        newBelievers,
        `${(
          newBelievers /
          total *
          100
        ).toFixed(1)}%`
      ],

      ...STATUS_ORDER.map(
        s => [
          s,
          counts[s],
          `${(
            counts[s] /
            total *
            100
          ).toFixed(1)}%`
        ]
      )
    ];


    els.summaryCards.innerHTML =
      cards
        .map(
          ([
            label,
            value,
            note
          ]) => `
            <div class="card">

              <span class="label">
                ${escapeHtml(label)}
              </span>

              <strong class="value">
                ${value}
              </strong>

              <span class="note">
                ${escapeHtml(note)}
              </span>

            </div>
          `
        )
        .join('');
  }


  /*
   * ========================================
   * 每週聚會人數趨勢
   * ========================================
   *
   * 趨勢圖使用「統計名單」為基準，不受下方一般分析篩選影響。
   * 大區空白 = 全會所；選大區但小區空白 = 該大區；
   * 大區 + 小區都有選 = 該小區。
   */

  function renderAreaButtons({
    container,
    items,
    selectedValue,
    allLabel,
    dataAttr,
    growthClassForValue = null
  }) {

    if (!container) {
      return;
    }

    const allSelected = !selectedValue;
    const allGrowthClass = growthClassForValue
      ? growthClassForValue('')
      : '';

    container.innerHTML = [
      `
        <button
          type="button"
          class="ios-filter-btn${allSelected ? ' is-selected' : ''}${allGrowthClass ? ` ${allGrowthClass}` : ''}"
          ${dataAttr}=""
        >
          <span class="ios-filter-dot" aria-hidden="true"></span>
          ${escapeHtml(allLabel)}
        </button>
      `,
      ...items.map(value => {
        const growthClass = growthClassForValue
          ? growthClassForValue(value)
          : '';

        return `
          <button
            type="button"
            class="ios-filter-btn${selectedValue === value ? ' is-selected' : ''}${growthClass ? ` ${growthClass}` : ''}"
            ${dataAttr}="${escapeAttr(value)}"
          >
            <span class="ios-filter-dot" aria-hidden="true"></span>
            ${escapeHtml(value)}
          </button>
        `;
      })
    ].join('');
  }


  /*
   * 自訂季別：1–4 月＝第一季、5–8 月＝第二季、9–12 月＝第三季。
   * 季平均採該季所有已匯入週次的實際聚會人數平均；
   * 最新季尚未結束時，使用目前已有的週次計算。
   */
  function getCustomQuarter(date) {
    const month = date.getMonth() + 1;

    return {
      year: date.getFullYear(),
      quarter: month <= 4 ? 1 : month <= 8 ? 2 : 3
    };
  }


  function getPreviousCustomQuarter(period) {
    return period.quarter > 1
      ? { year: period.year, quarter: period.quarter - 1 }
      : { year: period.year - 1, quarter: 3 };
  }


  function quarterKey(period) {
    return period
      ? `${period.year}Q${period.quarter}`
      : '';
  }


  function quarterLabel(period) {
    return quarterKey(period) || '—';
  }


  function parseQuarterKey(key) {
    const match = String(key || '').match(/^(\d{4})Q([123])$/);

    return match
      ? { year: Number(match[1]), quarter: Number(match[2]) }
      : null;
  }


  function quarterOrderValue(period) {
    return period ? period.year * 3 + period.quarter : -Infinity;
  }


  function getAvailableQuarterPeriods() {
    const seen = new Map();

    state.dateColumns.forEach(item => {
      const period = getCustomQuarter(item.date);
      seen.set(quarterKey(period), period);
    });

    return [...seen.values()].sort(
      (a, b) => quarterOrderValue(a) - quarterOrderValue(b)
    );
  }


  function getSelectedQuarterPeriods() {
    const available = getAvailableQuarterPeriods();

    if (!available.length) {
      return { from: null, to: null };
    }

    const availableKeys = new Set(available.map(quarterKey));
    let to = parseQuarterKey(state.quarterToKey);
    let from = parseQuarterKey(state.quarterFromKey);

    if (!to || !availableKeys.has(quarterKey(to))) {
      to = available[available.length - 1];
    }

    if (!from || !availableKeys.has(quarterKey(from)) || quarterOrderValue(from) >= quarterOrderValue(to)) {
      const actualPrevious = getPreviousCustomQuarter(to);
      from = available.find(period => quarterKey(period) === quarterKey(actualPrevious)) ||
        [...available].reverse().find(period => quarterOrderValue(period) < quarterOrderValue(to)) ||
        null;
    }

    return { from, to };
  }


  function buildQuarterCompareControls() {
    const available = getAvailableQuarterPeriods();

    if (!available.length) {
      return;
    }

    const selected = getSelectedQuarterPeriods();
    state.quarterFromKey = quarterKey(selected.from);
    state.quarterToKey = quarterKey(selected.to);

    if (els.quarterFromSelect) {
      const validFrom = available.filter(period =>
        selected.to && quarterOrderValue(period) < quarterOrderValue(selected.to)
      );

      els.quarterFromSelect.innerHTML = validFrom.map(period =>
        `<option value="${escapeAttr(quarterKey(period))}">${escapeHtml(quarterLabel(period))}</option>`
      ).join('');
      els.quarterFromSelect.value = state.quarterFromKey;
      els.quarterFromSelect.disabled = validFrom.length === 0;
    }

    if (els.quarterToSelect) {
      const from = parseQuarterKey(state.quarterFromKey);
      const validTo = available.filter(period =>
        !from || quarterOrderValue(period) > quarterOrderValue(from)
      );

      els.quarterToSelect.innerHTML = validTo.map(period =>
        `<option value="${escapeAttr(quarterKey(period))}">${escapeHtml(quarterLabel(period))}</option>`
      ).join('');

      if (!validTo.some(period => quarterKey(period) === state.quarterToKey)) {
        state.quarterToKey = validTo.length
          ? quarterKey(validTo[validTo.length - 1])
          : '';
      }

      els.quarterToSelect.value = state.quarterToKey;
      els.quarterToSelect.disabled = validTo.length === 0;
    }

    updateQuarterCompareLabels();
  }


  function updateQuarterCompareLabels() {
    const { from, to } = getSelectedQuarterPeriods();
    const fromLabel = quarterLabel(from);
    const toLabel = quarterLabel(to);

    if (els.trendFromQuarterLabel) els.trendFromQuarterLabel.textContent = fromLabel;
    if (els.trendToQuarterLabel) els.trendToQuarterLabel.textContent = toLabel;
    if (els.currentAgeQuarterLabel) els.currentAgeQuarterLabel.textContent = toLabel;
    if (els.quarterComparePeriodLabel) els.quarterComparePeriodLabel.textContent = `${fromLabel} → ${toLabel}`;
    if (els.quarterCompareFromLegend) els.quarterCompareFromLegend.textContent = fromLabel;
    if (els.quarterCompareToLegend) els.quarterCompareToLegend.textContent = toLabel;
  }


  function sameCustomQuarter(date, period) {
    const current = getCustomQuarter(date);

    return current.year === period.year &&
      current.quarter === period.quarter;
  }


  function getWeeklyAttendancePoints(people) {
    return state.dateColumns.map(dateColumn => {
      const count = people.reduce(
        (sum, person) => {
          const row = state.rows[person.rowNumber - 1];

          return sum + (
            row && isAttendance(row[dateColumn.col])
              ? 1
              : 0
          );
        },
        0
      );

      return {
        date: dateColumn.date,
        count
      };
    });
  }


  function getQuarterComparison(people) {
    if (!state.dateColumns.length) {
      return {
        latest: null,
        previous: null,
        diff: null
      };
    }

    const { from: previousPeriod, to: latestPeriod } =
      getSelectedQuarterPeriods();

    if (!previousPeriod || !latestPeriod) {
      return {
        latest: null,
        previous: null,
        diff: null,
        latestPeriod,
        previousPeriod
      };
    }

    const weeklyPoints = getWeeklyAttendancePoints(people);

    const averageFor = period => {
      const points = weeklyPoints.filter(
        point => sameCustomQuarter(point.date, period)
      );

      if (!points.length) {
        return null;
      }

      return points.reduce(
        (sum, point) => sum + point.count,
        0
      ) / points.length;
    };

    const latest = averageFor(latestPeriod);
    const previous = averageFor(previousPeriod);

    return {
      latest,
      previous,
      diff:
        latest === null || previous === null
          ? null
          : latest - previous,
      latestPeriod,
      previousPeriod
    };
  }


  function quarterGrowthClass(people) {
    const { diff } = getQuarterComparison(people);

    if (diff === null) {
      return 'trend-growth-neutral';
    }

    if (diff > 0.049) {
      return 'trend-growth-up';
    }

    if (diff < -0.049) {
      return 'trend-growth-down';
    }

    return 'trend-growth-flat';
  }


  function buildTrendFilters() {

    if (
      !els.trendDistrictFilter ||
      !els.trendSmallDistrictFilter ||
      !els.trendDistrictButtons
    ) {
      return;
    }

    const basePeople =
      getPopulationBase().people;

    const districts =
      unique(
        basePeople
          .map(p => p.district)
          .filter(Boolean)
      ).sort(
        (a, b) =>
          a.localeCompare(
            b,
            'zh-Hant',
            { numeric: true }
          )
      );

    const previousDistrict =
      els.trendDistrictFilter.value;

    if (
      previousDistrict &&
      !districts.includes(previousDistrict)
    ) {
      els.trendDistrictFilter.value = '';
      els.trendSmallDistrictFilter.value = '';
    }

    renderAreaButtons({
      container: els.trendDistrictButtons,
      items: districts,
      selectedValue: els.trendDistrictFilter.value,
      allLabel: '全會所',
      dataAttr: 'data-trend-district',
      growthClassForValue: value =>
        quarterGrowthClass(
          value
            ? basePeople.filter(person => person.district === value)
            : basePeople
        )
    });

    updateTrendSmallDistrictOptions();
  }


  function updateTrendSmallDistrictOptions() {

    if (
      !els.trendDistrictFilter ||
      !els.trendSmallDistrictFilter ||
      !els.trendSmallDistrictButtons
    ) {
      return;
    }

    const district =
      els.trendDistrictFilter.value;

    if (!district) {
      els.trendSmallDistrictFilter.value = '';

      if (els.trendSmallDistrictGroup) {
        els.trendSmallDistrictGroup.classList.add('hidden');
      }

      els.trendSmallDistrictButtons.innerHTML = '';
      return;
    }

    const smallDistricts =
      unique(
        getPopulationBase().people
          .filter(
            p =>
              p.district === district
          )
          .map(
            p => p.smallDistrict
          )
          .filter(Boolean)
      ).sort(
        (a, b) =>
          a.localeCompare(
            b,
            'zh-Hant',
            { numeric: true }
          )
      );

    if (
      els.trendSmallDistrictFilter.value &&
      !smallDistricts.includes(
        els.trendSmallDistrictFilter.value
      )
    ) {
      els.trendSmallDistrictFilter.value = '';
    }

    if (els.trendSmallDistrictGroup) {
      els.trendSmallDistrictGroup.classList.remove('hidden');
    }

    const districtPeople =
      getPopulationBase().people.filter(
        person => person.district === district
      );

    renderAreaButtons({
      container: els.trendSmallDistrictButtons,
      items: smallDistricts,
      selectedValue: els.trendSmallDistrictFilter.value,
      allLabel: '全部小區',
      dataAttr: 'data-trend-small-district',
      growthClassForValue: value =>
        quarterGrowthClass(
          value
            ? districtPeople.filter(person => person.smallDistrict === value)
            : districtPeople
        )
    });
  }


  function getTrendPeople() {

    const district =
      els.trendDistrictFilter?.value || '';

    const smallDistrict =
      els.trendSmallDistrictFilter?.value || '';

    return getPopulationBase().people.filter(
      person =>
        (
          !district ||
          person.district === district
        ) &&
        (
          !smallDistrict ||
          person.smallDistrict === smallDistrict
        )
    );
  }


  function getTrendScopeLabel() {

    const district =
      els.trendDistrictFilter?.value || '';

    const smallDistrict =
      els.trendSmallDistrictFilter?.value || '';

    if (!district) {
      return '全會所';
    }

    if (!smallDistrict) {
      return district;
    }

    return `${district}｜${smallDistrict}`;
  }


  function aggregateMonthlyPoints(points) {
    const months = new Map();

    points.forEach(point => {
      const date = point.date;
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;

      if (!months.has(key)) {
        months.set(key, {
          year: date.getFullYear(),
          month: date.getMonth(),
          sum: 0,
          weeks: 0
        });
      }

      const item = months.get(key);
      item.sum += Number(point.count || 0);
      item.weeks++;
    });

    return [...months.values()].map(item => ({
      date: new Date(item.year, item.month, 1),
      count: item.weeks ? item.sum / item.weeks : 0,
      weeks: item.weeks
    }));
  }


  function smoothSvgPath(points) {
    if (!points.length) {
      return '';
    }

    if (points.length === 1) {
      return `M ${points[0].x} ${points[0].y}`;
    }

    let path = `M ${points[0].x} ${points[0].y}`;

    for (let i = 1; i < points.length; i++) {
      const previous = points[i - 1];
      const current = points[i];
      const middleX = (previous.x + current.x) / 2;

      path += ` C ${middleX} ${previous.y}, ${middleX} ${current.y}, ${current.x} ${current.y}`;
    }

    return path;
  }


  const AGE_STRUCTURE_GROUPS = [
    '年長',
    '中壯',
    '青壯',
    '青職',
    '大學',
    '青少年'
  ];

  /*
   * 羣組固定配色：以「07 自然療癒色系」為主，
   * 補入相容的土色與柔和紫灰，確保六條趨勢線都有足夠辨識度。
   * 顏色固定綁定羣組，不因排序改變。
   */
  const AGE_STRUCTURE_COLORS = {
    '年長': '#405B4A',
    '中壯': '#6F8F76',
    '青壯': '#9A7E62',
    '青職': '#7FA184',
    '大學': '#756B8A',
    '青少年': '#A07F45'
  };

  const AGE_ASCENDING_GROUPS = [
    '青少年',
    '大學',
    '青職',
    '青壯',
    '中壯',
    '年長'
  ];


  function normalizeAgeStructureGroup(value) {
    const group = cleanGroupText(value);

    if (['國中', '高中', '中學'].includes(group)) {
      return '青少年';
    }

    if (group === '大專') {
      return '大學';
    }

    return AGE_STRUCTURE_GROUPS.includes(group)
      ? group
      : '';
  }


  function getQuarterGroupAverages(people, period) {
    const columns = state.dateColumns.filter(
      item => sameCustomQuarter(item.date, period)
    );

    const result = Object.fromEntries(
      AGE_STRUCTURE_GROUPS.map(group => [group, 0])
    );

    if (!columns.length) {
      return {
        averages: result,
        total: 0,
        weeks: 0
      };
    }

    AGE_STRUCTURE_GROUPS.forEach(group => {
      const groupPeople = people.filter(
        person => normalizeAgeStructureGroup(person.group) === group
      );

      const sum = columns.reduce((quarterSum, dateColumn) => {
        const weeklyCount = groupPeople.reduce((count, person) => {
          const row = state.rows[person.rowNumber - 1];
          return count + (
            row && isAttendance(row[dateColumn.col])
              ? 1
              : 0
          );
        }, 0);

        return quarterSum + weeklyCount;
      }, 0);

      result[group] = sum / columns.length;
    });

    return {
      averages: result,
      total: AGE_STRUCTURE_GROUPS.reduce(
        (sum, group) => sum + result[group],
        0
      ),
      weeks: columns.length
    };
  }


  function groupShare(stats, group) {
    return stats.total
      ? stats.averages[group] / stats.total * 100
      : 0;
  }


  function ageStructureColor(group) {
    return AGE_STRUCTURE_COLORS[group] || '#6F8793';
  }


  function groupsSortedByLatestShare(stats) {
    return [...AGE_STRUCTURE_GROUPS].sort((a, b) => {
      const diff = groupShare(stats, b) - groupShare(stats, a);

      if (Math.abs(diff) > 0.0001) {
        return diff;
      }

      return AGE_STRUCTURE_GROUPS.indexOf(a) -
        AGE_STRUCTURE_GROUPS.indexOf(b);
    });
  }


  function medianAgeGroup(stats) {
    if (!stats.total) {
      return '—';
    }

    const midpoint = stats.total / 2;
    let cumulative = 0;

    for (const group of AGE_ASCENDING_GROUPS) {
      cumulative += stats.averages[group] || 0;

      if (cumulative >= midpoint) {
        return group;
      }
    }

    return AGE_ASCENDING_GROUPS[AGE_ASCENDING_GROUPS.length - 1];
  }


  function renderCurrentAgePyramid() {
    if (!els.currentAgePyramid) {
      return;
    }

    const people = getTrendPeople();

    if (!state.dateColumns.length) {
      els.currentAgePyramid.innerHTML = '<div class="trend-empty compact">沒有可分析資料</div>';
      return;
    }

    const { to: latestPeriod } = getSelectedQuarterPeriods();

    if (!latestPeriod) {
      els.currentAgePyramid.innerHTML = '<div class="trend-empty compact">沒有可分析季度</div>';
      return;
    }

    const latest = getQuarterGroupAverages(people, latestPeriod);
    const sortedGroups = groupsSortedByLatestShare(latest);
    const maxShare = Math.max(
      ...sortedGroups.map(group => groupShare(latest, group)),
      1
    );

    els.currentAgePyramid.innerHTML = sortedGroups.map(group => {
      const average = latest.averages[group];
      const share = groupShare(latest, group);
      const width = share / maxShare * 100;
      const color = ageStructureColor(group);

      return `
        <div class="pyramid-row" style="--age-group-color:${escapeAttr(color)}">
          <span class="pyramid-label">
            <i class="pyramid-label-dot" aria-hidden="true"></i>
            ${escapeHtml(group)}
          </span>
          <div class="pyramid-track">
            <div class="pyramid-bar" style="width:${width.toFixed(1)}%"></div>
          </div>
          <span class="pyramid-value"><strong>${average.toFixed(1)}</strong><small>${share.toFixed(1)}%</small></span>
        </div>
      `;
    }).join('');

    if (els.currentAgeStructureMeta) {
      els.currentAgeStructureMeta.textContent =
        `${quarterLabel(latestPeriod)} 平均聚會結構｜${latest.weeks} 週｜六羣組合計 ${latest.total.toFixed(1)} 人／週`;
    }
  }


  function renderQuarterAgePyramid() {
    if (!els.quarterAgePyramid || !state.dateColumns.length) {
      return;
    }

    const people = getTrendPeople();
    const { from: previousPeriod, to: latestPeriod } =
      getSelectedQuarterPeriods();

    if (!previousPeriod || !latestPeriod) {
      els.quarterAgePyramid.innerHTML = '<div class="trend-empty compact">沒有足夠季度可比較</div>';
      return;
    }

    const latest = getQuarterGroupAverages(people, latestPeriod);
    const previous = getQuarterGroupAverages(people, previousPeriod);

    if (!previous.weeks) {
      els.quarterAgePyramid.innerHTML = '<div class="trend-empty compact">所選基準季沒有足夠資料可比較</div>';
      if (els.ageStructureSignal) {
        els.ageStructureSignal.innerHTML = `
          <div class="age-structure-highlight is-neutral">
            <span>中位數年齡層</span>
            <strong>資料不足</strong>
          </div>
          <div class="age-structure-highlight is-neutral">
            <span>結構趨勢</span>
            <strong>資料不足</strong>
          </div>
        `;
      }
      return;
    }

    /*
     * 兩個所選季度共用「比較季」的排序。
     * 比較季占比高的羣組在最上，基準季只跟著對齊比較。
     */
    const sortedGroups = groupsSortedByLatestShare(latest);

    const maxShare = Math.max(
      ...sortedGroups.flatMap(group => [
        groupShare(previous, group),
        groupShare(latest, group)
      ]),
      1
    );

    els.quarterAgePyramid.innerHTML = sortedGroups.map(group => {
      const prevShare = groupShare(previous, group);
      const latestShare = groupShare(latest, group);
      const prevWidth = prevShare / maxShare * 100;
      const latestWidth = latestShare / maxShare * 100;
      const diff = latestShare - prevShare;
      const diffClass = diff > .05 ? 'is-up' : diff < -.05 ? 'is-down' : 'is-flat';
      const sign = diff > 0 ? '+' : '';
      const color = ageStructureColor(group);

      return `
        <div class="pyramid-compare-row" style="--age-group-color:${escapeAttr(color)}">
          <div class="pyramid-half pyramid-half-left">
            <span class="pyramid-side-value">${prevShare.toFixed(1)}%</span>
            <div class="pyramid-compare-track">
              <div class="pyramid-compare-bar previous" style="width:${prevWidth.toFixed(1)}%"></div>
            </div>
          </div>
          <div class="pyramid-center-label">
            <strong><i class="pyramid-label-dot" aria-hidden="true"></i>${escapeHtml(group)}</strong>
            <small class="${diffClass}">${sign}${diff.toFixed(1)}</small>
          </div>
          <div class="pyramid-half pyramid-half-right">
            <div class="pyramid-compare-track">
              <div class="pyramid-compare-bar latest" style="width:${latestWidth.toFixed(1)}%"></div>
            </div>
            <span class="pyramid-side-value">${latestShare.toFixed(1)}%</span>
          </div>
        </div>
      `;
    }).join('');

    if (els.ageStructureSignal) {
      const olderGroups = ['年長', '中壯'];
      const youngerGroups = ['青職', '大學', '青少年'];
      const sumShares = (stats, groups) => groups.reduce(
        (sum, group) => sum + groupShare(stats, group),
        0
      );

      const olderPrev = sumShares(previous, olderGroups);
      const olderLatest = sumShares(latest, olderGroups);
      const youngerPrev = sumShares(previous, youngerGroups);
      const youngerLatest = sumShares(latest, youngerGroups);
      const olderDiff = olderLatest - olderPrev;
      const youngerDiff = youngerLatest - youngerPrev;

      const previousMedian = medianAgeGroup(previous);
      const latestMedian = medianAgeGroup(latest);
      const previousMedianIndex = AGE_ASCENDING_GROUPS.indexOf(previousMedian);
      const latestMedianIndex = AGE_ASCENDING_GROUPS.indexOf(latestMedian);

      let label = '大致穩定';
      let signalClass = 'is-stable';

      /*
       * 中位數年齡層跨層時視為強訊號；
       * 若中位數未跨層，再以年長端與年輕端占比 ±2 個百分點判讀。
       */
      if (latestMedianIndex > previousMedianIndex) {
        label = '年齡重心上移';
        signalClass = 'is-aging';
      } else if (latestMedianIndex < previousMedianIndex) {
        label = '年齡重心下移';
        signalClass = 'is-younger';
      } else if (olderDiff >= 2 && youngerDiff <= -2) {
        label = '年齡重心上移';
        signalClass = 'is-aging';
      } else if (olderDiff <= -2 && youngerDiff >= 2) {
        label = '年齡重心下移';
        signalClass = 'is-younger';
      }

      const smallSample = people.length < 30;
      const signOlder = olderDiff > 0 ? '+' : '';
      const signYounger = youngerDiff > 0 ? '+' : '';

      els.ageStructureSignal.innerHTML = `
        <span>年長＋中壯 ${olderLatest.toFixed(1)}%（${signOlder}${olderDiff.toFixed(1)} 個百分點）</span>
        <span>青職＋大學＋青少年 ${youngerLatest.toFixed(1)}%（${signYounger}${youngerDiff.toFixed(1)} 個百分點）</span>

        <div class="age-structure-highlight median-highlight">
          <span>中位數年齡層</span>
          <strong>${escapeHtml(previousMedian)} <b aria-hidden="true">→</b> ${escapeHtml(latestMedian)}</strong>
        </div>

        <div class="age-structure-highlight trend-highlight ${signalClass}">
          <span>結構趨勢</span>
          <strong>${escapeHtml(label)}</strong>
        </div>

        ${smallSample ? '<small>此範圍人數較少，結構變化請搭配實際人數判讀。</small>' : ''}
      `;
    }
  }


  function renderAgeStructurePanels() {
    renderCurrentAgePyramid();
    renderQuarterAgePyramid();
  }


  function renderTrend() {

    if (!els.trendChart) {
      return;
    }

    const people = getTrendPeople();

    const weeklyPoints = getWeeklyAttendancePoints(people);
    const points = aggregateMonthlyPoints(weeklyPoints);
    const scopeLabel = getTrendScopeLabel();
    const quarter = getQuarterComparison(people);

    updateQuarterCompareLabels();
    renderAgeStructurePanels();

    if (els.trendScopeLabel) {
      els.trendScopeLabel.textContent = `${scopeLabel}｜統計名單${people.length} 人`;
    }

    if (els.trendLatestCount) {
      els.trendLatestCount.textContent =
        quarter.latest === null
          ? '—'
          : quarter.latest.toFixed(1);
    }

    if (els.trendAverageCount) {
      els.trendAverageCount.textContent =
        quarter.previous === null
          ? '—'
          : quarter.previous.toFixed(1);
    }

    if (els.trendChangeText) {
      els.trendChangeText.classList.remove('is-up', 'is-down');

      if (quarter.diff === null) {
        els.trendChangeText.textContent = `較 ${quarterLabel(quarter.previousPeriod)} —`;
      } else {
        const sign = quarter.diff > 0 ? '+' : '';

        els.trendChangeText.textContent = `較 ${quarterLabel(quarter.previousPeriod)} ${sign}${quarter.diff.toFixed(1)} 人`;
        els.trendChangeText.classList.toggle('is-up', quarter.diff > 0);
        els.trendChangeText.classList.toggle('is-down', quarter.diff < 0);
      }
    }

    if (!points.length) {
      els.trendChart.innerHTML = '<div class="trend-empty">沒有可繪製的月份資料</div>';
      return;
    }

    // 圖表寬度直接跟著目前容器，不再用 min-width 撐出橫向捲動。
    const chartWidth = Math.max(320, Math.round(els.trendChart.clientWidth || 760));
    const chartHeight = chartWidth <= 680 ? 280 : 350;
    const left = chartWidth <= 420 ? 42 : 58;
    const right = chartWidth <= 420 ? 12 : 24;
    const top = 24;
    const bottom = 56;
    const plotWidth = chartWidth - left - right;
    const plotHeight = chartHeight - top - bottom;

    const rawMax = Math.max(...points.map(p => p.count), 1);

    const step = rawMax <= 20
      ? 5
      : rawMax <= 60
        ? 10
        : rawMax <= 150
          ? 25
          : rawMax <= 300
            ? 50
            : 100;

    const yMax = Math.ceil(rawMax / step) * step;

    const xAt = index =>
      points.length === 1
        ? left + plotWidth / 2
        : left + index / (points.length - 1) * plotWidth;

    const yAt = value =>
      top + plotHeight - value / yMax * plotHeight;

    const chartPoints = points.map((point, index) => ({
      x: Number(xAt(index).toFixed(1)),
      y: Number(yAt(point.count).toFixed(1)),
      point,
      index
    }));

    const path = smoothSvgPath(chartPoints);
    const yTicks = 4;

    const grid = Array.from(
      { length: yTicks + 1 },
      (_, i) => {
        const value = Math.round(yMax * (yTicks - i) / yTicks);
        const y = top + i / yTicks * plotHeight;

        return `
          <line
            class="trend-grid-line"
            x1="${left}"
            y1="${y}"
            x2="${chartWidth - right}"
            y2="${y}"
          />
          <text
            class="trend-y-label"
            x="${left - 12}"
            y="${y + 4}"
            text-anchor="end"
          >${value}</text>
        `;
      }
    ).join('');

    // 小螢幕只降低 X 軸文字密度；所有月份資料點仍完整保留。
    const maxXLabels = Math.max(3, Math.floor((chartWidth - left - right) / 62));
    const xLabelEvery = Math.max(1, Math.ceil(points.length / maxXLabels));
    const xLabels = points.map((point, index) => {
      if (index % xLabelEvery !== 0 && index !== points.length - 1) return '';
      const date = point.date;
      const label = `${date.getFullYear()}/${date.getMonth() + 1}`;

      return `
        <text
          class="trend-x-label"
          x="${xAt(index)}"
          y="${chartHeight - 20}"
          text-anchor="middle"
        >${label}</text>
      `;
    }).join('');

    const circles = chartPoints.map(({ x, y, point }) => {
      const monthText = `${point.date.getFullYear()}/${point.date.getMonth() + 1}`;

      return `
        <g class="trend-point-group">
          <circle
            class="trend-point-hit"
            cx="${x}"
            cy="${y}"
            r="11"
            tabindex="0"
          >
            <title>${escapeHtml(monthText)}｜月平均 ${point.count.toFixed(1)} 人｜${point.weeks} 週</title>
          </circle>
          <circle
            class="trend-point"
            cx="${x}"
            cy="${y}"
            r="4"
            aria-hidden="true"
          />
        </g>
      `;
    }).join('');

    els.trendChart.innerHTML = `
      <svg
        class="trend-svg"
        width="100%"
        height="${chartHeight}"
        viewBox="0 0 ${chartWidth} ${chartHeight}"
        aria-hidden="true"
      >
        ${grid}
        <path class="trend-line" d="${path}" />
        ${circles}
        ${xLabels}
      </svg>
    `;
  }


  /*
   * ========================================
   * 羣組成長趨勢
   * ========================================
   *
   * 1. 使用與上方每週人數相同的「全會所 / 大區 / 小區」範圍。
   * 2. 國小、學齡前不納入。
   * 3. 國中、高中、中學統一合併為「青少年」。
   * 4. 每條線將每週資料彙整為每月平均，再以平滑曲線呈現。
   */

  const GROUP_TREND_COLORS = {
    '年長': '#405B4A',
    '中壯': '#6F8F76',
    '青壯': '#9A7E62',
    '青職': '#7FA184',
    '大學': '#756B8A',
    '青少年': '#A07F45'
  };


  function cleanGroupText(value) {
    return String(value ?? '')
      .trim()
      .replace(/\s+/g, '');
  }


  function normalizeTrendGroup(group) {
    const value =
      cleanGroupText(group);

    if (!value) {
      return null;
    }

    if (
      value === '國小' ||
      value === '學齡前'
    ) {
      return null;
    }

    if (
      [
        '國中',
        '高中',
        '中學'
      ].includes(value)
    ) {
      return '青少年';
    }

    return value;
  }


  function getAvailableTrendGroups() {
    const sourcePeople =
      state.groupTrendMode === 'districts'
        ? getPopulationBase().people
        : getPopulationBase().people;

    const found =
      unique(
        sourcePeople
          .map(
            person =>
              normalizeTrendGroup(
                person.group
              )
          )
          .filter(Boolean)
      );

    const preferred = [
      '年長',
      '中壯',
      '青壯',
      '青職',
      '大學',
      '大專',
      '青少年'
    ];

    return [
      ...preferred.filter(
        group => found.includes(group)
      ),
      ...found
        .filter(
          group => !preferred.includes(group)
        )
        .sort(
          (a, b) =>
            a.localeCompare(
              b,
              'zh-Hant',
              { numeric: true }
            )
        )
    ];
  }


  function getTrendGroupColor(
    group,
    availableGroups
  ) {
    if (GROUP_TREND_COLORS[group]) {
      return GROUP_TREND_COLORS[group];
    }

    /*
     * 若匯入資料出現額外羣組，才使用備援色；
     * 主要六羣組顏色固定，不會因按鈕順序改變。
     */
    const fallback = [
      '#567B78',
      '#8A5F69',
      '#6F8793'
    ];
    const index = Math.max(0, availableGroups.indexOf(group));

    return fallback[index % fallback.length];
  }


  function buildGroupTrendButtons() {
    if (!els.groupTrendButtons) {
      return;
    }

    const groups =
      getAvailableTrendGroups();

    state.selectedTrendGroups =
      new Set(
        [...state.selectedTrendGroups]
          .filter(
            group => groups.includes(group)
          )
      );

    if (
      !state.trendGroupsInitialized
    ) {
      state.selectedTrendGroups =
        new Set(groups);

      state.trendGroupsInitialized =
        true;
    }

    els.groupTrendButtons.innerHTML =
      groups.length
        ? groups
            .map(
              group => {
                const selected =
                  state.selectedTrendGroups.has(
                    group
                  );

                const color =
                  getTrendGroupColor(
                    group,
                    groups
                  );

                return `
                  <button
                    type="button"
                    class="group-trend-btn${selected ? ' is-selected' : ''}"
                    data-trend-group="${escapeAttr(group)}"
                    aria-pressed="${selected ? 'true' : 'false'}"
                    style="--group-trend-color:${escapeAttr(color)}"
                  >
                    <span class="group-trend-btn-dot" aria-hidden="true"></span>
                    <span>${escapeHtml(group)}</span>
                  </button>
                `;
              }
            )
            .join('')
        : '<div class="group-trend-no-groups">目前沒有可分析的羣組</div>';

    updateGroupTrendMeta();
  }


  function updateGroupTrendMeta() {
    if (els.groupTrendScopeLabel) {
      els.groupTrendScopeLabel.textContent =
        state.groupTrendMode === 'districts'
          ? '各大區比較'
          : '全會所';
    }

    if (!els.groupTrendSelectedText) {
      return;
    }

    const selected =
      getAvailableTrendGroups()
        .filter(
          group =>
            state.selectedTrendGroups.has(
              group
            )
        );

    els.groupTrendSelectedText.textContent =
      selected.length
        ? state.groupTrendMode === 'districts'
          ? `比較羣組：${selected[0]}`
          : `目前顯示：${selected.join('＋')}`
        : '目前未選擇羣組';
  }


  function renderGroupTrend() {
    if (!els.groupTrendChart) {
      return;
    }

    updateGroupTrendMeta();

    const availableGroups = getAvailableTrendGroups();
    const selectedGroups = availableGroups.filter(
      group => state.selectedTrendGroups.has(group)
    );

    if (!selectedGroups.length) {
      els.groupTrendChart.innerHTML =
        '<div class="trend-empty">請點選至少一個羣組查看成長趨勢</div>';
      return;
    }

    const buildPoints = people => aggregateMonthlyPoints(
      state.dateColumns.map(dateColumn => ({
        date: dateColumn.date,
        count: people.reduce((sum, person) => {
          const row = state.rows[person.rowNumber - 1];
          return sum + (row && isAttendance(row[dateColumn.col]) ? 1 : 0);
        }, 0)
      }))
    );

    let series;

    if (state.groupTrendMode === 'districts') {
      const selectedGroup = selectedGroups[0];
      const basePeople = getPopulationBase().people.filter(
        person => normalizeTrendGroup(person.group) === selectedGroup
      );
      const districts = unique(basePeople.map(person => person.district).filter(Boolean))
        .sort((a, b) => a.localeCompare(b, 'zh-Hant', { numeric: true }));
      const districtColors = ['#405B4A', '#756B8A', '#A07F45', '#567B78', '#8A5F69', '#6F8793'];

      series = districts.map((district, index) => ({
        group: district,
        color: districtColors[index % districtColors.length],
        points: buildPoints(basePeople.filter(person => person.district === district))
      }));
    } else {
      const people = getPopulationBase().people;
      series = selectedGroups.map(group => ({
        group,
        color: getTrendGroupColor(group, availableGroups),
        points: buildPoints(people.filter(
          person => normalizeTrendGroup(person.group) === group
        ))
      }));
    }

    if (els.groupTrendDistrictLegend) {
      if (state.groupTrendMode === 'districts' && series.length) {
        els.groupTrendDistrictLegend.innerHTML = series.map(item => `
          <span class="group-trend-district-legend-item">
            <i style="--district-trend-color:${escapeAttr(item.color)}"></i>
            ${escapeHtml(item.group)}
          </span>
        `).join('');
        els.groupTrendDistrictLegend.classList.remove('hidden');
      } else {
        els.groupTrendDistrictLegend.innerHTML = '';
        els.groupTrendDistrictLegend.classList.add('hidden');
      }
    }

    const monthCount = Math.max(
      ...series.map(item => item.points.length),
      0
    );

    if (!monthCount) {
      els.groupTrendChart.innerHTML =
        '<div class="trend-empty">沒有可繪製的月份資料</div>';
      return;
    }

    // 與上方圖表一致：完整縮放到容器寬度，不產生橫向捲動。
    const chartWidth = Math.max(320, Math.round(els.groupTrendChart.clientWidth || 760));
    const chartHeight = chartWidth <= 680 ? 280 : 350;
    const left = chartWidth <= 420 ? 42 : 58;
    const right = chartWidth <= 420 ? 12 : 24;
    const top = 24;
    const bottom = 56;
    const plotWidth = chartWidth - left - right;
    const plotHeight = chartHeight - top - bottom;

    const allValues = series.flatMap(
      item => item.points.map(point => point.count)
    );

    const rawMax = Math.max(...allValues, 1);

    const step = rawMax <= 20
      ? 5
      : rawMax <= 60
        ? 10
        : rawMax <= 150
          ? 25
          : rawMax <= 300
            ? 50
            : 100;

    const yMax = Math.ceil(rawMax / step) * step;

    const xAt = index =>
      monthCount === 1
        ? left + plotWidth / 2
        : left + index / (monthCount - 1) * plotWidth;

    const yAt = value =>
      top + plotHeight - value / yMax * plotHeight;

    const yTicks = 4;

    const grid = Array.from(
      { length: yTicks + 1 },
      (_, i) => {
        const value = Math.round(yMax * (yTicks - i) / yTicks);
        const y = top + i / yTicks * plotHeight;

        return `
          <line
            class="trend-grid-line"
            x1="${left}"
            y1="${y}"
            x2="${chartWidth - right}"
            y2="${y}"
          />
          <text
            class="trend-y-label"
            x="${left - 12}"
            y="${y + 4}"
            text-anchor="end"
          >${value}</text>
        `;
      }
    ).join('');

    const referencePoints = series.find(item => item.points.length)?.points || [];

    const maxXLabels = Math.max(3, Math.floor((chartWidth - left - right) / 62));
    const xLabelEvery = Math.max(1, Math.ceil(referencePoints.length / maxXLabels));
    const xLabels = referencePoints.map((point, index) => {
      if (index % xLabelEvery !== 0 && index !== referencePoints.length - 1) return '';
      const label = `${point.date.getFullYear()}/${point.date.getMonth() + 1}`;

      return `
        <text
          class="trend-x-label"
          x="${xAt(index)}"
          y="${chartHeight - 20}"
          text-anchor="middle"
        >${label}</text>
      `;
    }).join('');

    const paths = series.map(item => {
      const chartPoints = item.points.map((point, index) => ({
        x: Number(xAt(index).toFixed(1)),
        y: Number(yAt(point.count).toFixed(1)),
        point,
        index
      }));

      const path = smoothSvgPath(chartPoints);

      const hitPoints = chartPoints.map(({ x, y, point }) => {
        const monthText = `${point.date.getFullYear()}/${point.date.getMonth() + 1}`;

        return `
          <g class="group-trend-point-group">
            <circle
              class="group-trend-hit"
              cx="${x}"
              cy="${y}"
              r="10"
              tabindex="0"
            >
              <title>${escapeHtml(item.group)}｜${escapeHtml(monthText)}｜月平均 ${point.count.toFixed(1)} 人｜${point.weeks} 週</title>
            </circle>
            <circle
              class="group-trend-point"
              cx="${x}"
              cy="${y}"
              r="3.5"
              style="fill:${escapeAttr(item.color)}"
              aria-hidden="true"
            />
          </g>
        `;
      }).join('');

      return `
        <g class="group-trend-series">
          <path
            class="group-trend-line"
            d="${path}"
            style="stroke:${escapeAttr(item.color)}"
          />
          ${hitPoints}
        </g>
      `;
    }).join('');

    els.groupTrendChart.innerHTML = `
      <svg
        class="trend-svg"
        width="100%"
        height="${chartHeight}"
        viewBox="0 0 ${chartWidth} ${chartHeight}"
        aria-hidden="true"
      >
        ${grid}
        ${paths}
        ${xLabels}
      </svg>
    `;
  }


  function renderOverall() {

    const people =
      getPopulationBase().people;

    const counts =
      countStatuses(
        people
      );


    const total =
      people.length || 1;


    els.overallBar.innerHTML =
      STATUS_ORDER
        .map(
          s => {

            const pct =
              counts[s] /
              total *
              100;


            return `
              <div
                class="seg-${STATUS_CLASS[s]}"
                style="width:${pct}%"
                title="${escapeAttr(
                  `${s} ${counts[s]} 人 (${pct.toFixed(1)}%)`
                )}"
              ></div>
            `;
          }
        )
        .join('');


    els.overallLegend.innerHTML =
      STATUS_ORDER
        .map(
          s => {

            const pct =
              counts[s] /
              total *
              100;


            return `
              <div class="legend-item">

                <span>
                  <i class="dot ${STATUS_CLASS[s]}"></i>
                  ${escapeHtml(s)}
                </span>

                <strong>
                  ${counts[s]}
                  <small>
                    ${pct.toFixed(1)}%
                  </small>
                </strong>

              </div>
            `;
          }
        )
        .join('');
  }


  function renderDistricts() {

    const groups =
      groupBy(
        getPopulationBase().people,
        p =>
          p.district ||
          '未分類'
      );


    els.districtBody.innerHTML =
      [...groups.entries()]
        .sort(
          (a, b) =>
            a[0].localeCompare(
              b[0],
              'zh-Hant'
            )
        )
        .map(
          ([
            district,
            people
          ]) => {

            const c =
              countStatuses(
                people
              );


            const stableRate =
              people.length
                ? (
                    c[STATUS.WEEKLY] +
                    c[STATUS.REGULAR]
                  ) /
                  people.length *
                  100
                : 0;


            const nb =
              people.filter(
                p =>
                  p.newBelieverStatus ===
                  'yes'
              ).length;


            return `
              <tr>

                <td>
                  <strong>
                    ${escapeHtml(district)}
                  </strong>
                </td>

                <td>${people.length}</td>
                <td>${nb}</td>
                <td>${c[STATUS.WEEKLY]}</td>
                <td>${c[STATUS.REGULAR]}</td>
                <td>${c[STATUS.OCCASIONAL]}</td>
                <td>${c[STATUS.SPORADIC]}</td>
                <td>${c[STATUS.INACTIVE]}</td>
                <td>${stableRate.toFixed(1)}%</td>

              </tr>
            `;
          }
        )
        .join('');
  }


  function analysisFilterGroups() {
    const found = unique(
      getPopulationBase().people
        .map(p => {
          const g = cleanGroupText(p.group);
          return ['國中', '高中', '中學'].includes(g) ? '青少年' : g;
        })
        .filter(Boolean)
    );
    const preferred = ['年長','中壯','青壯','青職','大學','大專','青少年','國小','學齡前'];
    return [...preferred.filter(g => found.includes(g)), ...found.filter(g => !preferred.includes(g)).sort((a,b)=>a.localeCompare(b,'zh-Hant'))];
  }

  function makeAnalysisButton(value, label, selected, attr, detail='') {
    return `<button type="button" class="ios-filter-btn ${selected ? 'is-selected' : ''}" ${attr}="${escapeAttr(value)}" aria-pressed="${selected}">
      <span class="analysis-group-main"><i class="ios-filter-dot"></i><span>${escapeHtml(label)}</span></span>
      ${detail ? `<span class="analysis-group-detail">${escapeHtml(detail)}</span>` : ''}
    </button>`;
  }

  function renderAnalysisFilterButtons() {
    if (!els.analysisDistrictButtons) return;

    const basePeople = getPopulationBase().people;
    const districts = unique(
      basePeople.map(p => p.district).filter(Boolean)
    ).sort((a,b)=>a.localeCompare(b,'zh-Hant'));

    const d = els.districtFilter.value;
    els.analysisDistrictButtons.innerHTML =
      makeAnalysisButton('', '全部', !d, 'data-analysis-district') +
      districts.map(x =>
        makeAnalysisButton(x, x, d === x, 'data-analysis-district')
      ).join('');

    /*
     * 小區只有在選定大區後才出現，而且可以複選。
     * 空集合代表「全部小區」。
     */
    const smalls = d
      ? unique(
          basePeople
            .filter(p => p.district === d)
            .map(p => p.smallDistrict)
            .filter(Boolean)
        ).sort((a,b)=>a.localeCompare(b,'zh-Hant',{numeric:true}))
      : [];

    state.selectedAnalysisSmallDistricts = new Set(
      [...state.selectedAnalysisSmallDistricts].filter(x => smalls.includes(x))
    );

    els.analysisSmallDistrictRow.classList.toggle('hidden', !d);
    if (d) {
      els.analysisSmallDistrictButtons.innerHTML =
        makeAnalysisButton('', '全部', !state.selectedAnalysisSmallDistricts.size, 'data-analysis-small') +
        smalls.map(x =>
          makeAnalysisButton(
            x,
            x,
            state.selectedAnalysisSmallDistricts.has(x),
            'data-analysis-small'
          )
        ).join('');
    } else {
      els.analysisSmallDistrictButtons.innerHTML = '';
    }

    const areaPeople = basePeople.filter(p =>
      (!d || p.district === d) &&
      (!state.selectedAnalysisSmallDistricts.size ||
        state.selectedAnalysisSmallDistricts.has(p.smallDistrict))
    );

    /* 羣組只顯示名稱；青少年仍代表 國中＋高中＋中學，但不顯示拆分統計。 */
    els.analysisGroupButtons.innerHTML = analysisFilterGroups()
      .map(g => makeAnalysisButton(
        g,
        g,
        state.selectedGroups.has(g),
        'data-analysis-group'
      ))
      .join('');

    els.analysisStatusButtons.innerHTML = STATUS_ORDER
      .map(x => makeAnalysisButton(
        x,
        x,
        state.selectedStatuses.has(x),
        'data-analysis-status'
      ))
      .join('');

    /*
     * 初信只保留一顆按鈕：
     * 未按 = 全部；按下 = 只看初信；再按一次 = 取消。
     * 若目前完全沒有受浸日期來源，就把整列隱藏。
     */
    const hasBaptismData =
      state.indexes.baptism >= 0 ||
      state.baptismByName.size > 0;

    if (els.analysisBelieverRow) {
      els.analysisBelieverRow.classList.toggle('hidden', !hasBaptismData);
    }

    if (!hasBaptismData) {
      els.newBelieverFilter.value = '';
      els.analysisBelieverButtons.innerHTML = '';
    } else {
      const onlyNewBelievers = els.newBelieverFilter.value === 'yes';
      els.analysisBelieverButtons.innerHTML = makeAnalysisButton(
        'yes',
        '初信',
        onlyNewBelievers,
        'data-analysis-believer'
      );
    }
  }

  function buildFilters() {

    preserveOptions(
      els.districtFilter,
      unique(
        getPopulationBase().people.map(
          p => p.district
        )
      )
    );


    updateSmallDistrictOptions();

    buildGroupOptions();

    buildStatusOptions();
    renderAnalysisFilterButtons();
  }


  function availableGroups() {

    return unique(
      getPopulationBase().people
        .map(p => {
          const g = cleanGroupText(p.group);
          return ['國中', '高中', '中學'].includes(g) ? '青少年' : g;
        })
        .filter(Boolean)
    )
      .sort(
        (a, b) =>
          a.localeCompare(
            b,
            'zh-Hant'
          )
      );
  }


  function buildGroupOptions() {

    const groups =
      availableGroups();


    state.selectedGroups =
      new Set(
        [
          ...state.selectedGroups
        ].filter(
          g =>
            groups.includes(g)
        )
      );


    els.groupFilterOptions.innerHTML =
      groups
        .map(
          g => `
            <label class="group-option">

              <input
                type="checkbox"
                value="${escapeAttr(g)}"
                ${
                  state.selectedGroups.has(g)
                    ? 'checked'
                    : ''
                }
              >

              <span>
                ${escapeHtml(g)}
              </span>

            </label>
          `
        )
        .join('');


    updateGroupSummary();
  }


  function updateGroupSummary() {

    const selected =
      [
        ...state.selectedGroups
      ];


    if (
      !selected.length
    ) {

      els.groupFilterSummary.textContent =
        '全部';

    } else if (
      selected.length <= 2
    ) {

      els.groupFilterSummary.textContent =
        selected.join('＋');

    } else {

      els.groupFilterSummary.textContent =
        `已選 ${selected.length} 組`;
    }
  }


  function setSelectedGroups(
    groups
  ) {

    const available =
      availableGroups();


    const aliases = {

      college: [
        '大專',
        '大學'
      ],

      youth: [
        '青職'
      ],

      junior: [
        '國中'
      ],

      senior: [
        '高中'
      ],

      child: [
        '國小'
      ]
    };


    const resolve =
      key =>
        aliases[key]
          .filter(
            x =>
              available.includes(x)
          );


    let wanted = [];


    if (
      groups === 'all'
    ) {
      wanted = [];
    }


    if (
      groups ===
      'college-youth'
    ) {

      wanted = [
        ...resolve('college'),
        ...resolve('youth')
      ];
    }


    if (
      groups === 'teen'
    ) {

      wanted = ['青少年'];
    }


    if (
      groups === 'student'
    ) {

      wanted = [
        ...resolve('college'),
        ...resolve('junior'),
        ...resolve('senior')
      ];
    }


    if (
      groups === 'child'
    ) {

      wanted = [
        ...resolve('child')
      ];
    }


    state.selectedGroups =
      new Set(wanted);


    buildGroupOptions();
    renderAnalysisFilterButtons();

    renderPeople();
  }


  function buildStatusOptions() {

    state.selectedStatuses =
      new Set(
        [
          ...state.selectedStatuses
        ].filter(
          s =>
            STATUS_ORDER.includes(s)
        )
      );


    els.statusFilterOptions.innerHTML =
      STATUS_ORDER
        .map(
          status => `
            <label class="group-option">

              <input
                type="checkbox"
                value="${escapeAttr(status)}"
                ${
                  state.selectedStatuses.has(status)
                    ? 'checked'
                    : ''
                }
              >

              <span>
                <i class="dot ${STATUS_CLASS[status]}"></i>
                ${escapeHtml(status)}
              </span>

            </label>
          `
        )
        .join('');


    updateStatusSummary();
  }


  function updateStatusSummary() {

    const selected =
      STATUS_ORDER.filter(
        s =>
          state.selectedStatuses.has(s)
      );


    if (
      !selected.length
    ) {

      els.statusFilterSummary.textContent =
        '全部';

    } else if (
      selected.length === 1
    ) {

      els.statusFilterSummary.textContent =
        selected[0];

    } else {

      els.statusFilterSummary.textContent =
        `已選 ${selected.length} 項`;
    }
  }


  function setSelectedStatuses(
    statuses
  ) {

    state.selectedStatuses =
      new Set(statuses);


    buildStatusOptions();
    renderAnalysisFilterButtons();

    renderPeople();
  }


  function updateSmallDistrictOptions() {

    const selectedDistrict =
      els.districtFilter.value;


    const peopleInDistrict =
      selectedDistrict
        ? getPopulationBase().people.filter(
            p =>
              p.district ===
              selectedDistrict
          )
        : getPopulationBase().people;


    preserveOptions(
      els.smallDistrictFilter,
      unique(
        peopleInDistrict.map(
          p =>
            p.smallDistrict
        )
      )
    );
  }


  function preserveOptions(
    select,
    values
  ) {

    const previous =
      select.value;


    select.innerHTML =
      '<option value="">全部</option>' +

      values
        .filter(Boolean)
        .sort(
          (a, b) =>
            a.localeCompare(
              b,
              'zh-Hant'
            )
        )
        .map(
          v => `
            <option value="${escapeAttr(v)}">
              ${escapeHtml(v)}
            </option>
          `
        )
        .join('');


    if (
      [
        ...select.options
      ].some(
        o =>
          o.value ===
          previous
      )
    ) {

      select.value =
        previous;
    }
  }


  /* ========================================
     排除功能
  ======================================== */

  function getAvailableHistoryWeeks() {

    if (
      !state.dateColumns.length
    ) {
      return 0;
    }


    if (
      state.dateColumns.length === 1
    ) {
      return 1;
    }


    const firstDate =
      state.dateColumns[0].date;


    const lastDate =
      state.dateColumns[
        state.dateColumns.length - 1
      ].date;


    return (
      Math.floor(
        (
          lastDate -
          firstDate
        ) /
        MS_WEEK
      ) + 1
    );
  }


  function shouldExcludePerson(
    person,
    maxTotalAttendance,
    absenceWeeks,
    availableHistoryWeeks
  ) {

    const hasTotalCondition =
      maxTotalAttendance !== null;


    const hasAbsenceCondition =
      absenceWeeks !== null;


    if (
      !hasTotalCondition &&
      !hasAbsenceCondition
    ) {
      return false;
    }


    const matchesLowAttendance =
      hasTotalCondition
        ? person.totalAttendance <=
          maxTotalAttendance
        : false;


    let matchesLongAbsence =
      false;


    if (
      hasAbsenceCondition
    ) {

      if (
        person.weeksSinceLastAttendance !==
        null
      ) {

        matchesLongAbsence =
          person.weeksSinceLastAttendance >=
          absenceWeeks;

      } else {

        matchesLongAbsence =
          availableHistoryWeeks >=
          absenceWeeks;
      }
    }


    if (
      hasTotalCondition &&
      hasAbsenceCondition
    ) {

      return (
        matchesLowAttendance &&
        matchesLongAbsence
      );
    }


    if (
      hasTotalCondition
    ) {

      return matchesLowAttendance;
    }


    return matchesLongAbsence;
  }


  /*
   * ========================================
   * 統計名單
   * ========================================
   *
   * 這兩個排除條件不是一般「分析篩選」，
   * 而是先決定整份報表要分析哪些人。
   * 上方摘要、比例、大區比較與四張群組圖，
   * 都以這裡排除後的統計名單為準。
   */

  function getPopulationBase() {

    const maxTotalAttendance =
      els.totalAttendanceFilter.value === ''
        ? null
        : Number(els.totalAttendanceFilter.value);

    const absenceWeeks =
      els.absenceWeeksFilter.value === ''
        ? null
        : Number(els.absenceWeeksFilter.value);

    const availableHistoryWeeks =
      getAvailableHistoryWeeks();

    const people =
      state.people.filter(
        p =>
          !shouldExcludePerson(
            p,
            maxTotalAttendance,
            absenceWeeks,
            availableHistoryWeeks
          )
      );

    return {
      people,
      originalCount: state.people.length,
      excludedCount: state.people.length - people.length,
      exclusionActive:
        maxTotalAttendance !== null ||
        absenceWeeks !== null
    };
  }


  function renderPopulationScope() {

    const base =
      getPopulationBase();

    if (els.populationOriginalCount) {
      els.populationOriginalCount.textContent =
        base.originalCount;
    }

    if (els.populationActiveCount) {
      els.populationActiveCount.textContent =
        base.people.length;
    }

    if (els.populationExcludedCount) {
      els.populationExcludedCount.textContent =
        base.excludedCount;
    }
  }


  /*
   * ========================================
   * 圖表群組判斷
   * ========================================
   */

  function matchesChartGroup(
    person,
    chartGroup
  ) {

    if (!chartGroup) {
      return true;
    }

    if (chartGroup === '青少年') {
      return [
        '國中',
        '高中',
        '中學'
      ].includes(person.group);
    }

    return person.group === chartGroup;
  }


  function getGeneralFilteredPeople() {

    const q =
      els.searchInput.value
        .trim()
        .toLowerCase();

    const district =
      els.districtFilter.value;

    const selectedSmalls =
      state.selectedAnalysisSmallDistricts;

    const nb =
      els.newBelieverFilter.value;

    const selectedGroups =
      state.selectedGroups;

    const selectedStatuses =
      state.selectedStatuses;

    const population =
      getPopulationBase();

    const visible =
      population.people.filter(
        p => {

          const matchesSearch =
            !q ||
            p.name.toLowerCase().includes(q);

          const matchesDistrict =
            !district ||
            p.district === district;

          const matchesSmallDistrict =
            !selectedSmalls.size ||
            selectedSmalls.has(p.smallDistrict);

          const normalizedFilterGroup =
            ['國中', '高中', '中學'].includes(cleanGroupText(p.group))
              ? '青少年'
              : cleanGroupText(p.group);

          const matchesGroup =
            !selectedGroups.size ||
            selectedGroups.has(normalizedFilterGroup);

          const matchesStatus =
            !selectedStatuses.size ||
            selectedStatuses.has(p.status);

          const matchesNewBeliever =
            !nb ||
            p.newBelieverStatus === nb;

          return (
            matchesSearch &&
            matchesDistrict &&
            matchesSmallDistrict &&
            matchesGroup &&
            matchesStatus &&
            matchesNewBeliever
          );
        }
      );

    return {
      people: visible,
      populationCount: population.people.length,
      originalCount: population.originalCount,
      excludedCount: population.excludedCount,
      exclusionActive: population.exclusionActive
    };
  }


  function matchesChartTypeStatus(
    person,
    chartType
  ) {

    if (!chartType) {
      return true;
    }

    if (chartType === 'stable') {
      return (
        person.status === STATUS.WEEKLY ||
        person.status === STATUS.REGULAR
      );
    }

    if (chartType === 'care') {
      return (
        person.status === STATUS.OCCASIONAL ||
        person.status === STATUS.SPORADIC
      );
    }

    if (chartType === 'inactive') {
      return person.status === STATUS.INACTIVE;
    }

    return true;
  }


  function peopleSmallDistrictKey(
    person
  ) {

    return `${person.district}::${person.smallDistrict}`;
  }


  function sortZh(values) {

    return [...values].sort(
      (a, b) =>
        a.localeCompare(
          b,
          'zh-Hant',
          {
            numeric: true
          }
        )
    );
  }


  function updatePeopleAreaFilterUI(
    candidates
  ) {

    if (
      !els.peopleDistrictOptions ||
      !els.peopleDistrictSummary ||
      !els.peopleSmallDistrictOptions ||
      !els.peopleSmallDistrictSummary
    ) {
      return;
    }


    const availableDistricts =
      new Set(
        candidates
          .map(p => p.district)
          .filter(Boolean)
      );


    state.selectedPeopleDistricts =
      new Set(
        [...state.selectedPeopleDistricts]
          .filter(
            district =>
              availableDistricts.has(district)
          )
      );


    const districtList =
      sortZh(availableDistricts);


    els.peopleDistrictOptions.innerHTML =
      districtList.length
        ? [
            `
              <button
                type="button"
                class="ios-filter-btn people-area-btn${!state.selectedPeopleDistricts.size ? ' is-selected' : ''}"
                data-people-district=""
              >
                <span class="ios-filter-dot" aria-hidden="true"></span>
                全部
              </button>
            `,
            ...districtList.map(
              district => {

                const count =
                  candidates.filter(
                    p => p.district === district
                  ).length;

                return `
                  <button
                    type="button"
                    class="ios-filter-btn people-area-btn${state.selectedPeopleDistricts.has(district) ? ' is-selected' : ''}"
                    data-people-district="${escapeAttr(district)}"
                  >
                    <span class="ios-filter-dot" aria-hidden="true"></span>
                    <span>${escapeHtml(district)}</span>
                    <small>${count}</small>
                  </button>
                `;
              }
            )
          ].join('')
        : '<div class="people-filter-empty">目前沒有可選大區</div>';


    const selectedDistricts =
      sortZh(state.selectedPeopleDistricts);


    els.peopleDistrictSummary.textContent =
      !selectedDistricts.length
        ? '大區：全部'
        : selectedDistricts.length === 1
          ? `大區：${selectedDistricts[0]}`
          : `大區：已選 ${selectedDistricts.length} 項`;


    const smallCandidates =
      selectedDistricts.length
        ? candidates.filter(
            p =>
              state.selectedPeopleDistricts.has(
                p.district
              )
          )
        : [];


    const availableSmallMap =
      new Map();


    smallCandidates.forEach(
      p => {

        if (!p.smallDistrict) {
          return;
        }

        const key =
          peopleSmallDistrictKey(p);

        if (!availableSmallMap.has(key)) {
          availableSmallMap.set(
            key,
            {
              key,
              district: p.district,
              smallDistrict: p.smallDistrict,
              count: 0
            }
          );
        }

        availableSmallMap.get(key).count++;
      }
    );


    state.selectedPeopleSmallDistricts =
      new Set(
        [...state.selectedPeopleSmallDistricts]
          .filter(
            key =>
              availableSmallMap.has(key)
          )
      );


    const smallList =
      [...availableSmallMap.values()]
        .sort(
          (a, b) => {

            const districtCompare =
              a.district.localeCompare(
                b.district,
                'zh-Hant',
                { numeric: true }
              );

            if (districtCompare) {
              return districtCompare;
            }

            return a.smallDistrict.localeCompare(
              b.smallDistrict,
              'zh-Hant',
              { numeric: true }
            );
          }
        );


    if (
      els.peopleSmallDistrictMultiSelect
    ) {

      els.peopleSmallDistrictMultiSelect
        .classList
        .toggle(
          'hidden',
          !selectedDistricts.length
        );

      if (!selectedDistricts.length) {
        els.peopleSmallDistrictMultiSelect.open = false;
      }
    }


    els.peopleSmallDistrictOptions.innerHTML =
      smallList.length
        ? [
            `
              <button
                type="button"
                class="ios-filter-btn people-area-btn${!state.selectedPeopleSmallDistricts.size ? ' is-selected' : ''}"
                data-people-small-district=""
              >
                <span class="ios-filter-dot" aria-hidden="true"></span>
                全部小區
              </button>
            `,
            ...smallList.map(
              item => `
                <button
                  type="button"
                  class="ios-filter-btn people-area-btn${state.selectedPeopleSmallDistricts.has(item.key) ? ' is-selected' : ''}"
                  data-people-small-district="${escapeAttr(item.key)}"
                  title="${escapeAttr(`${item.district}｜${item.smallDistrict} ${item.count} 人`)}"
                >
                  <span class="ios-filter-dot" aria-hidden="true"></span>
                  <span>${escapeHtml(item.smallDistrict)}</span>
                  <small>${item.count}</small>
                </button>
              `
            )
          ].join('')
        : '<div class="people-filter-empty">所選大區目前沒有小區資料</div>';


    const selectedSmallCount =
      state.selectedPeopleSmallDistricts.size;


    els.peopleSmallDistrictSummary.textContent =
      !selectedSmallCount
        ? '小區：全部'
        : selectedSmallCount === 1
          ? `小區：${(
              availableSmallMap.get(
                [...state.selectedPeopleSmallDistricts][0]
              )?.smallDistrict || ''
            )}`
          : `小區：已選 ${selectedSmallCount} 項`;


    const localActive =
      Boolean(
        state.selectedPeopleDistricts.size ||
        state.selectedPeopleSmallDistricts.size
      );


    if (els.clearPeopleAreaFilter) {
      els.clearPeopleAreaFilter
        .classList
        .toggle(
          'hidden',
          !localActive
        );
    }
  }


  function clearPeopleAreaFilters() {

    state.selectedPeopleDistricts =
      new Set();

    state.selectedPeopleSmallDistricts =
      new Set();

    renderPeople();
  }


  function getPeopleAreaFilteredPeople(
    candidates
  ) {

    return candidates.filter(
      person => {

        const matchesDistrict =
          !state.selectedPeopleDistricts.size ||
          state.selectedPeopleDistricts.has(
            person.district
          );

        const matchesSmallDistrict =
          !state.selectedPeopleSmallDistricts.size ||
          state.selectedPeopleSmallDistricts.has(
            peopleSmallDistrictKey(person)
          );

        return (
          matchesDistrict &&
          matchesSmallDistrict
        );
      }
    );
  }


  function renderPeople() {

    const base =
      getGeneralFilteredPeople();

    const chartType =
      state.chartType;

    const chartGroup =
      state.chartGroup;

    const chartDistrict =
      state.chartDistrict;

    const chartVisible =
      base.people.filter(
        p =>
          matchesChartGroup(p, chartGroup) &&
          (
            !chartDistrict ||
            p.district === chartDistrict
          ) &&
          matchesChartTypeStatus(p, chartType)
      );


    /*
     * 名單區的大區 / 小區複選，
     * 只以目前已列出的 chartVisible 為選項來源。
     */
    updatePeopleAreaFilterUI(
      chartVisible
    );


    const visible =
      getPeopleAreaFilteredPeople(
        chartVisible
      );


    const peopleAreaActive =
      Boolean(
        state.selectedPeopleDistricts.size ||
        state.selectedPeopleSmallDistricts.size
      );

    const chartActive =
      Boolean(
        chartType ||
        chartGroup ||
        chartDistrict
      );

    if (chartActive || peopleAreaActive) {

      const sourceCount =
        chartVisible.length;

      const labels = [];

      if (chartActive) {
        labels.push('圖表篩選');
      }

      if (peopleAreaActive) {
        labels.push('大區／小區篩選');
      }

      els.resultCount.textContent =
        `目前${labels.join('＋')}：${visible.length} / ${sourceCount} 人`;

    } else {
      els.resultCount.textContent =
        `顯示 ${visible.length} / ${base.populationCount} 人`;
    }

    els.peopleBody.innerHTML =
      visible
        .map(
          p => `
            <tr>
              <td>${escapeHtml(p.district)}</td>
              <td>${escapeHtml(p.smallDistrict)}</td>
              <td><strong>${escapeHtml(p.name)}</strong></td>
              <td>${escapeHtml(p.group)}</td>
              <td>${p.baptismDate ? fmtDate(p.baptismDate) : '—'}</td>
              <td>
                ${
                  p.newBelieverStatus === 'yes'
                    ? '<span class="new-believer">初信</span>'
                    : p.newBelieverStatus === 'no'
                      ? '非初信'
                      : '—'
                }
              </td>
              <td>
                <span class="status ${STATUS_CLASS[p.status]}">
                  ${escapeHtml(p.status)}
                </span>
              </td>
              <td>${p.lastAttendanceDate ? fmtDate(p.lastAttendanceDate) : '—'}</td>
              <td>${p.recentAttendance} / ${p.recentWeeks}</td>
              <td>${(p.recentRate * 100).toFixed(1)}%</td>
              <td>${p.totalAttendance}</td>
            </tr>
          `
        )
        .join('');

    document.dispatchEvent(
      new CustomEvent('analysisBaseChanged')
    );
  }


  globalThis.AttendanceDashboardAPI = {
    getAnalysisBasePeople() {
      return getGeneralFilteredPeople()
        .people
        .map(
          p => ({
            district: p.district,
            group: p.group,
            status: p.status
          })
        );
    }
  };


  /*
   * ========================================
   * 圖表篩選 UI
   * ========================================
   */

  function updateChartFilterUI() {

    if (
      !els.chartFilterIndicator ||
      !els.chartFilterText
    ) {
      return;
    }


    if (
      !state.chartType ||
      !state.chartGroup
    ) {

      els.chartFilterIndicator
        .classList
        .add('hidden');


      els.chartFilterText.textContent =
        '';


      document
        .querySelectorAll(
          '.age-filter-trigger'
        )
        .forEach(
          element =>
            element.classList.remove(
              'is-selected'
            )
        );


      return;
    }


    const typeLabel =
      state.chartType === 'care'
        ? '需加強牧養'
        : state.chartType === 'inactive'
          ? '待關心聖徒'
          : '穩定聚會';

    const description =
      state.chartDistrict
        ? `${state.chartGroup} × ${state.chartDistrict}`
        : state.chartGroup;

    els.chartFilterText.textContent =
      `圖表篩選：${typeLabel}｜${description}`;


    els.chartFilterIndicator
      .classList
      .remove('hidden');


    /*
     * 更新圖表選取外觀
     */
    document
      .querySelectorAll(
        '.age-filter-trigger'
      )
      .forEach(
        element => {

          const group =
            element.dataset.ageGroup ||
            '';


          const district =
            element.dataset.ageDistrict ||
            '';


          const type =
            element.dataset.chartType ||
            'stable';

          const selected =
            type === state.chartType &&
            group === state.chartGroup &&
            district === state.chartDistrict;


          element.classList.toggle(
            'is-selected',
            selected
          );
        }
      );
  }


  function clearChartFilter() {

    state.chartType = '';

    state.chartGroup = '';

    state.chartDistrict = '';


    renderPeople();

    updateChartFilterUI();
  }


  function applyChartFilter(
    type,
    group,
    district
  ) {

    /*
     * 點同一個項目第二次：
     * 取消。
     */
    if (
      state.chartType === type &&
      state.chartGroup === group &&
      state.chartDistrict === district
    ) {

      clearChartFilter();

      return;
    }


    state.chartType =
      type;


    state.chartGroup =
      group;


    state.chartDistrict =
      district;


    renderPeople();

    updateChartFilterUI();


    /*
     * 自動捲到人員明細。
     */
    if (
      els.peoplePanel
    ) {

      els.peoplePanel.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  }


  function closeMultiSelects(
    except = null
  ) {

    [
      els.groupMultiSelect,
      els.statusMultiSelect,
      els.peopleDistrictMultiSelect,
      els.peopleSmallDistrictMultiSelect
    ].forEach(
      details => {

        if (
          details &&
          details !== except
        ) {

          details.open =
            false;
        }
      }
    );
  }


  function groupBy(
    items,
    fn
  ) {

    const m =
      new Map();


    items.forEach(
      x => {

        const k =
          fn(x);


        if (
          !m.has(k)
        ) {

          m.set(
            k,
            []
          );
        }


        m.get(k).push(x);
      }
    );


    return m;
  }


  function unique(arr) {

    return [
      ...new Set(arr)
    ];
  }


  function escapeHtml(v) {

    return String(
      v ?? ''
    ).replace(
      /[&<>'"]/g,
      c => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&#39;',
        '"': '&quot;'
      }[c])
    );
  }


  function escapeAttr(v) {

    return escapeHtml(v);
  }


  async function onAttendanceFile(file) {

    els.error.textContent =
      '';


    els.fileName.textContent =
      file.name;


    try {

      if (
        !globalThis.XLSX
      ) {

        throw new Error(
          'Excel 解析元件尚未載入。請確認網路連線，或依 README 將 SheetJS 改為本機 vendor。'
        );
      }


      const buffer =
        await file.arrayBuffer();


      analyzeWorkbook(
        buffer,
        file.name
      );


    } catch (err) {

      console.error(err);


      els.error.textContent =
        err?.message ||
        '無法讀取這份 Excel。';


      els.dashboard.classList.add(
        'hidden'
      );
    }
  }


  async function onBaptismFile(file) {

    els.error.textContent =
      '';


    els.baptismFileName.textContent =
      file.name;


    try {

      if (
        !globalThis.XLSX
      ) {

        throw new Error(
          'Excel 解析元件尚未載入。請確認網路連線，或依 README 將 SheetJS 改為本機 vendor。'
        );
      }


      const buffer =
        await file.arrayBuffer();


      analyzeBaptismWorkbook(
        buffer,
        file.name
      );


    } catch (err) {

      console.error(err);


      els.error.textContent =
        err?.message ||
        '無法讀取這份受浸報表。';
    }
  }


  function clearData() {

    state.fileName = '';

    state.rows = [];

    state.dateColumns = [];

    state.people = [];

    state.recentCols = [];

    state.baptismFileName = '';

    state.baptismByName =
      new Map();

    state.windowWeeks = 12;


    state.selectedGroups =
      new Set();


    state.selectedStatuses =
      new Set();


    state.selectedAnalysisSmallDistricts =
      new Set();


    state.selectedPeopleDistricts =
      new Set();

    state.selectedPeopleSmallDistricts =
      new Set();


    state.chartType = '';

    state.chartGroup = '';

    state.chartDistrict = '';


    state.selectedTrendGroups =
      new Set();

    state.trendGroupsInitialized =
      false;

    state.quarterFromKey = '';
    state.quarterToKey = '';


    updateChartFilterUI();


    els.fileInput.value =
      '';


    els.baptismFileInput.value =
      '';


    els.fileName.textContent =
      '尚未選擇點名報表';


    els.baptismFileName.textContent =
      '尚未選擇受浸報表';


    els.error.textContent =
      '';


    els.dashboard.classList.add(
      'hidden'
    );


    els.clearBtn.disabled =
      true;


    els.searchInput.value =
      '';


    els.districtFilter.value =
      '';


    els.smallDistrictFilter.value =
      '';


    if (els.trendDistrictFilter) {
      els.trendDistrictFilter.value = '';
    }

    if (els.trendSmallDistrictFilter) {
      els.trendSmallDistrictFilter.value = '';
      els.trendSmallDistrictFilter.disabled = true;
    }


    els.totalAttendanceFilter.value =
      '';


    els.absenceWeeksFilter.value =
      '';


    els.newBelieverFilter.value =
      '';


    closeMultiSelects();
  }


  /*
   * ========================================
   * Excel
   * ========================================
   */

  els.fileInput.addEventListener(
    'change',
    e => {

      const file =
        e.target.files?.[0];


      if (file) {

        onAttendanceFile(file);
      }
    }
  );


  els.baptismFileInput.addEventListener(
    'change',
    e => {

      const file =
        e.target.files?.[0];


      if (file) {

        onBaptismFile(file);
      }
    }
  );


  /*
   * ========================================
   * 季度比較選擇
   * ========================================
   */

  if (els.quarterFromSelect) {
    els.quarterFromSelect.addEventListener('change', () => {
      state.quarterFromKey = els.quarterFromSelect.value || '';

      const from = parseQuarterKey(state.quarterFromKey);
      const to = parseQuarterKey(state.quarterToKey);

      if (from && to && quarterOrderValue(from) >= quarterOrderValue(to)) {
        state.quarterToKey = '';
      }

      buildQuarterCompareControls();
      buildTrendFilters();
      renderTrend();
      renderGroupTrend();
    });
  }

  if (els.quarterToSelect) {
    els.quarterToSelect.addEventListener('change', () => {
      state.quarterToKey = els.quarterToSelect.value || '';

      const from = parseQuarterKey(state.quarterFromKey);
      const to = parseQuarterKey(state.quarterToKey);

      if (from && to && quarterOrderValue(from) >= quarterOrderValue(to)) {
        state.quarterFromKey = '';
      }

      buildQuarterCompareControls();
      buildTrendFilters();
      renderTrend();
      renderGroupTrend();
    });
  }


  /*
   * ========================================
   * 每週趨勢篩選
   * ========================================
   */

  if (els.trendDistrictButtons) {

    els.trendDistrictButtons.addEventListener(
      'click',
      e => {
        const button = e.target.closest('[data-trend-district]');
        if (!button) {
          return;
        }

        const nextDistrict =
          button.dataset.trendDistrict || '';

        if (els.trendDistrictFilter.value !== nextDistrict) {
          els.trendDistrictFilter.value = nextDistrict;
          els.trendSmallDistrictFilter.value = '';
        }

        buildTrendFilters();
        renderTrend();
        buildGroupTrendButtons();
        renderGroupTrend();
      }
    );
  }


  if (els.trendSmallDistrictButtons) {

    els.trendSmallDistrictButtons.addEventListener(
      'click',
      e => {
        const button = e.target.closest('[data-trend-small-district]');
        if (!button) {
          return;
        }

        els.trendSmallDistrictFilter.value =
          button.dataset.trendSmallDistrict || '';

        updateTrendSmallDistrictOptions();
        renderTrend();
        buildGroupTrendButtons();
        renderGroupTrend();
      }
    );
  }


  /*
   * ========================================
   * 羣組成長趨勢：iPhone App 式複選按鈕
   * ========================================
   */

  document.addEventListener('click', e => {
    const districtBtn = e.target.closest('[data-analysis-district]');
    if (districtBtn) {
      els.districtFilter.value = districtBtn.dataset.analysisDistrict || '';
      state.selectedAnalysisSmallDistricts = new Set();
      els.smallDistrictFilter.value = '';
      updateSmallDistrictOptions();
      renderAnalysisFilterButtons();
      renderPeople();
      return;
    }
    const smallBtn = e.target.closest('[data-analysis-small]');
    if (smallBtn) {
      const small = smallBtn.dataset.analysisSmall || '';
      if (!small) {
        state.selectedAnalysisSmallDistricts = new Set();
      } else if (state.selectedAnalysisSmallDistricts.has(small)) {
        state.selectedAnalysisSmallDistricts.delete(small);
      } else {
        state.selectedAnalysisSmallDistricts.add(small);
      }
      els.smallDistrictFilter.value = '';
      renderAnalysisFilterButtons();
      renderPeople();
      return;
    }
    const groupBtn = e.target.closest('[data-analysis-group]');
    if (groupBtn) {
      const g=groupBtn.dataset.analysisGroup;
      if (state.selectedGroups.has(g)) state.selectedGroups.delete(g); else state.selectedGroups.add(g);
      buildGroupOptions(); renderAnalysisFilterButtons(); renderPeople(); return;
    }
    const statusBtn = e.target.closest('[data-analysis-status]');
    if (statusBtn) {
      const st=statusBtn.dataset.analysisStatus;
      if (state.selectedStatuses.has(st)) state.selectedStatuses.delete(st); else state.selectedStatuses.add(st);
      buildStatusOptions(); renderAnalysisFilterButtons(); renderPeople(); return;
    }
    const believerBtn = e.target.closest('[data-analysis-believer]');
    if (believerBtn) {
      const value = believerBtn.dataset.analysisBeliever || '';
      els.newBelieverFilter.value =
        els.newBelieverFilter.value === value ? '' : value;
      renderAnalysisFilterButtons();
      renderPeople();
      return;
    }
  });

  document.addEventListener('click', e => {
    const infoButton = e.target.closest('[data-info-target]');
    if (infoButton) {
      const target = document.getElementById(infoButton.dataset.infoTarget || '');
      if (target) {
        const opening = target.classList.contains('hidden');
        target.classList.toggle('hidden', !opening);
        infoButton.setAttribute('aria-expanded', opening ? 'true' : 'false');
      }
      return;
    }

    const modeButton = e.target.closest('[data-group-trend-mode]');
    if (modeButton) {
      state.groupTrendMode = modeButton.dataset.groupTrendMode === 'districts' ? 'districts' : 'groups';
      if (state.groupTrendMode === 'districts') {
        const groups = getAvailableTrendGroups();
        const firstSelected = groups.find(group => state.selectedTrendGroups.has(group)) || groups[0];
        state.selectedTrendGroups = firstSelected ? new Set([firstSelected]) : new Set();
      }
      document.querySelectorAll('[data-group-trend-mode]').forEach(button => {
        const selected = button.dataset.groupTrendMode === state.groupTrendMode;
        button.classList.toggle('is-selected', selected);
        button.setAttribute('aria-pressed', selected ? 'true' : 'false');
      });
      buildGroupTrendButtons();
      renderGroupTrend();
      return;
    }
  });

  if (els.groupTrendButtons) {
    els.groupTrendButtons.addEventListener(
      'click',
      e => {
        const button =
          e.target.closest(
            '[data-trend-group]'
          );

        if (!button) {
          return;
        }

        const group =
          button.dataset.trendGroup || '';

        if (!group) {
          return;
        }

        if (state.groupTrendMode === 'districts') {
          state.selectedTrendGroups = new Set([group]);
        } else if (state.selectedTrendGroups.has(group)) {
          state.selectedTrendGroups.delete(group);
        } else {
          state.selectedTrendGroups.add(group);
        }

        buildGroupTrendButtons();
        renderGroupTrend();
      }
    );
  }


  /*
   * ========================================
   * 大區
   * ========================================
   */

  els.districtFilter.addEventListener(
    'change',
    () => {

      closeMultiSelects();

      updateSmallDistrictOptions();
      renderAnalysisFilterButtons();

      renderPeople();
    }
  );


  /*
   * ========================================
   * 統計名單設定
   * ========================================
   */

  [
    els.totalAttendanceFilter,
    els.absenceWeeksFilter
  ].forEach(
    el => {

      const refreshPopulation =
        () => {

          closeMultiSelects();

          state.chartType = '';
          state.chartGroup = '';
          state.chartDistrict = '';

          state.selectedPeopleDistricts =
            new Set();

          state.selectedPeopleSmallDistricts =
            new Set();

          renderAll();
        };

      el.addEventListener(
        'change',
        refreshPopulation
      );
    }
  );


  /*
   * ========================================
   * 一般篩選
   * ========================================
   */

  [
    els.searchInput,
    els.smallDistrictFilter,
    els.newBelieverFilter
  ].forEach(
    el => {

      el.addEventListener(
        'input',
        () => {

          closeMultiSelects();

          renderAnalysisFilterButtons();
          renderPeople();
        }
      );


      el.addEventListener(
        'change',
        () => {

          closeMultiSelects();

          renderAnalysisFilterButtons();
          renderPeople();
        }
      );


      el.addEventListener(
        'focus',
        () =>
          closeMultiSelects()
      );
    }
  );


  /*
   * ========================================
   * 羣組
   * ========================================
   */

  els.groupFilterOptions.addEventListener(
    'change',
    e => {

      if (
        !e.target.matches(
          'input[type="checkbox"]'
        )
      ) {
        return;
      }


      if (
        e.target.checked
      ) {

        state.selectedGroups.add(
          e.target.value
        );

      } else {

        state.selectedGroups.delete(
          e.target.value
        );
      }


      updateGroupSummary();
      renderAnalysisFilterButtons();

      renderPeople();
    }
  );


  document
    .querySelectorAll(
      '[data-group-preset]'
    )
    .forEach(
      btn => {

        btn.addEventListener(
          'click',
          () =>
            setSelectedGroups(
              btn.dataset.groupPreset
            )
        );
      }
    );


  els.clearGroupFilter.addEventListener(
    'click',
    () =>
      setSelectedGroups(
        'all'
      )
  );


  els.closeGroupFilter.addEventListener(
    'click',
    () => {

      els.groupMultiSelect.open =
        false;
    }
  );


  /*
   * ========================================
   * 聚會情況
   * ========================================
   */

  els.statusFilterOptions.addEventListener(
    'change',
    e => {

      if (
        !e.target.matches(
          'input[type="checkbox"]'
        )
      ) {
        return;
      }


      if (
        e.target.checked
      ) {

        state.selectedStatuses.add(
          e.target.value
        );

      } else {

        state.selectedStatuses.delete(
          e.target.value
        );
      }


      updateStatusSummary();
      renderAnalysisFilterButtons();

      renderPeople();
    }
  );


  els.clearStatusFilter.addEventListener(
    'click',
    () =>
      setSelectedStatuses([])
  );


  els.closeStatusFilter.addEventListener(
    'click',
    () => {

      els.statusMultiSelect.open =
        false;
    }
  );


  /*
   * ========================================
   * Multi select
   * ========================================
   */

  els.groupMultiSelect.addEventListener(
    'toggle',
    () => {

      if (
        els.groupMultiSelect.open
      ) {

        closeMultiSelects(
          els.groupMultiSelect
        );
      }
    }
  );


  els.statusMultiSelect.addEventListener(
    'toggle',
    () => {

      if (
        els.statusMultiSelect.open
      ) {

        closeMultiSelects(
          els.statusMultiSelect
        );
      }
    }
  );


  document
    .querySelectorAll(
      'select'
    )
    .forEach(
      select => {

        select.addEventListener(
          'pointerdown',
          () =>
            closeMultiSelects()
        );


        select.addEventListener(
          'focus',
          () =>
            closeMultiSelects()
        );
      }
    );


  document.addEventListener(
    'pointerdown',
    e => {

      const insideGroup =
        els.groupMultiSelect.contains(
          e.target
        );


      const insideStatus =
        els.statusMultiSelect.contains(
          e.target
        );


      const insidePeopleDistrict =
        els.peopleDistrictMultiSelect &&
        els.peopleDistrictMultiSelect.contains(
          e.target
        );


      const insidePeopleSmallDistrict =
        els.peopleSmallDistrictMultiSelect &&
        els.peopleSmallDistrictMultiSelect.contains(
          e.target
        );


      if (
        !insideGroup &&
        !insideStatus &&
        !insidePeopleDistrict &&
        !insidePeopleSmallDistrict
      ) {

        closeMultiSelects();
      }
    }
  );


  /*
   * ========================================
   * 人員明細：大區 / 小區複選
   * ========================================
   */

  if (els.peopleDistrictOptions) {

    els.peopleDistrictOptions.addEventListener(
      'click',
      e => {

        const button =
          e.target.closest(
            '[data-people-district]'
          );

        if (!button) {
          return;
        }

        const district =
          button.dataset.peopleDistrict || '';

        if (!district) {
          state.selectedPeopleDistricts = new Set();
          state.selectedPeopleSmallDistricts = new Set();
          renderPeople();
          return;
        }

        if (state.selectedPeopleDistricts.has(district)) {
          state.selectedPeopleDistricts.delete(district);
        } else {
          state.selectedPeopleDistricts.add(district);
        }

        renderPeople();
      }
    );
  }


  if (els.peopleSmallDistrictOptions) {

    els.peopleSmallDistrictOptions.addEventListener(
      'click',
      e => {

        const button =
          e.target.closest(
            '[data-people-small-district]'
          );

        if (!button) {
          return;
        }

        const key =
          button.dataset.peopleSmallDistrict || '';

        if (!key) {
          state.selectedPeopleSmallDistricts = new Set();
          renderPeople();
          return;
        }

        if (state.selectedPeopleSmallDistricts.has(key)) {
          state.selectedPeopleSmallDistricts.delete(key);
        } else {
          state.selectedPeopleSmallDistricts.add(key);
        }

        renderPeople();
      }
    );
  }


  if (els.clearPeopleDistrictFilter) {

    els.clearPeopleDistrictFilter.addEventListener(
      'click',
      () => {

        state.selectedPeopleDistricts =
          new Set();

        state.selectedPeopleSmallDistricts =
          new Set();

        renderPeople();
      }
    );
  }


  if (els.clearPeopleSmallDistrictFilter) {

    els.clearPeopleSmallDistrictFilter.addEventListener(
      'click',
      () => {

        state.selectedPeopleSmallDistricts =
          new Set();

        renderPeople();
      }
    );
  }


  if (els.clearPeopleAreaFilter) {

    els.clearPeopleAreaFilter.addEventListener(
      'click',
      clearPeopleAreaFilters
    );
  }


  if (els.closePeopleDistrictFilter) {

    els.closePeopleDistrictFilter.addEventListener(
      'click',
      () => {
        els.peopleDistrictMultiSelect.open = false;
      }
    );
  }


  if (els.closePeopleSmallDistrictFilter) {

    els.closePeopleSmallDistrictFilter.addEventListener(
      'click',
      () => {
        els.peopleSmallDistrictMultiSelect.open = false;
      }
    );
  }


  if (els.peopleDistrictMultiSelect) {

    els.peopleDistrictMultiSelect.addEventListener(
      'toggle',
      () => {

        if (els.peopleDistrictMultiSelect.open) {
          closeMultiSelects(
            els.peopleDistrictMultiSelect
          );
        }
      }
    );
  }


  if (els.peopleSmallDistrictMultiSelect) {

    els.peopleSmallDistrictMultiSelect.addEventListener(
      'toggle',
      () => {

        if (els.peopleSmallDistrictMultiSelect.open) {
          closeMultiSelects(
            els.peopleSmallDistrictMultiSelect
          );
        }
      }
    );
  }


  /*
   * ========================================
   * 圖表 → 人員明細
   * ========================================
   *
   * age-analysis.js 產生的按鈕
   * 都會帶有 .age-filter-trigger。
   */

  document.addEventListener(
    'click',
    e => {

      const trigger =
        e.target.closest(
          '.age-filter-trigger'
        );


      if (
        !trigger
      ) {
        return;
      }


      const group =
        trigger.dataset.ageGroup ||
        '';


      const district =
        trigger.dataset.ageDistrict ||
        '';


      const type =
        trigger.dataset.chartType ||
        'stable';


      if (
        !group
      ) {
        return;
      }


      applyChartFilter(
        type,
        group,
        district
      );
    }
  );


  /*
   * 四張分析圖重新產生 DOM 後，
   * 恢復目前圖表篩選的選取外觀。
   */

  document.addEventListener(
    'ageAnalysisRendered',
    updateChartFilterUI
  );


  /*
   * 人員明細右上角：
   * 清除圖表篩選
   */

  if (
    els.clearChartFilter
  ) {

    els.clearChartFilter.addEventListener(
      'click',
      clearChartFilter
    );
  }


  /*
   * ========================================
   * 清除全部資料
   * ========================================
   */

  els.clearBtn.addEventListener(
    'click',
    clearData
  );

  // 桌機視窗縮放或手機旋轉時，依新的可用寬度重畫兩張趨勢圖。
  let trendResizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(trendResizeTimer);
    trendResizeTimer = setTimeout(() => {
      if (!state.rows.length) return;
      renderTrend();
      renderGroupTrend();
    }, 120);
  });

})();